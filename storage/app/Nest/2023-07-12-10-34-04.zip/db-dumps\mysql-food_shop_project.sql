
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `advance_salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advance_salaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `advance_salary` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `advance_salaries` WRITE;
/*!40000 ALTER TABLE `advance_salaries` DISABLE KEYS */;
INSERT INTO `advance_salaries` VALUES (1,1,'July','2023','0','2023-07-01 01:45:01',NULL),(2,2,'July','2023','0','2023-07-01 02:11:01',NULL),(3,3,'July','2023','0','2023-07-01 08:11:27',NULL),(4,4,'July','2023','500','2023-07-04 07:08:40','2023-07-04 07:09:06'),(5,5,'July','2023','500','2023-07-04 14:06:19','2023-07-04 14:08:02');
/*!40000 ALTER TABLE `advance_salaries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `month` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `attendances` WRITE;
/*!40000 ALTER TABLE `attendances` DISABLE KEYS */;
INSERT INTO `attendances` VALUES (1,1,'01-07-2023','01','07','2023','Present','2023-07-02 05:06:44','2023-07-02 05:06:44'),(2,2,'01-07-2023','01','07','2023','Present','2023-07-02 05:06:44','2023-07-02 05:06:44'),(3,3,'01-07-2023','01','07','2023','Present','2023-07-02 05:06:44','2023-07-02 05:06:44'),(4,1,'02-07-2023','02','07','2023','Present','2023-07-02 05:06:51','2023-07-02 05:06:51'),(5,2,'02-07-2023','02','07','2023','Present','2023-07-02 05:06:51','2023-07-02 05:06:51'),(6,3,'02-07-2023','02','07','2023','Present','2023-07-02 05:06:51','2023-07-02 05:06:51'),(7,1,'03-07-2023','03','07','2023','Absent','2023-07-02 05:06:59','2023-07-02 05:06:59'),(8,2,'03-07-2023','03','07','2023','Absent','2023-07-02 05:06:59','2023-07-02 05:06:59'),(9,3,'03-07-2023','03','07','2023','Present','2023-07-02 05:06:59','2023-07-02 05:06:59'),(10,1,'04-07-2023','04','07','2023','Absent','2023-07-02 05:07:09','2023-07-02 05:07:09'),(11,2,'04-07-2023','04','07','2023','Present','2023-07-02 05:07:09','2023-07-02 05:07:09'),(12,3,'04-07-2023','04','07','2023','Absent','2023-07-02 05:07:09','2023-07-02 05:07:09'),(13,1,'05-07-2023','05','07','2023','Present','2023-07-02 05:07:21','2023-07-02 05:07:21'),(14,2,'05-07-2023','05','07','2023','Absent','2023-07-02 05:07:21','2023-07-02 05:07:21'),(15,3,'05-07-2023','05','07','2023','Absent','2023-07-02 05:07:21','2023-07-02 05:07:21'),(19,1,'06-07-2023','06','07','2023','Absent','2023-07-04 07:11:44','2023-07-04 07:11:44'),(20,2,'06-07-2023','06','07','2023','Absent','2023-07-04 07:11:44','2023-07-04 07:11:44'),(21,3,'06-07-2023','06','07','2023','Absent','2023-07-04 07:11:44','2023-07-04 07:11:44'),(22,4,'06-07-2023','06','07','2023','Absent','2023-07-04 07:11:44','2023-07-04 07:11:44'),(23,1,'07-07-2023','07','07','2023','Absent','2023-07-04 07:12:27','2023-07-04 07:12:27'),(24,2,'07-07-2023','07','07','2023','Absent','2023-07-04 07:12:27','2023-07-04 07:12:27'),(25,3,'07-07-2023','07','07','2023','Absent','2023-07-04 07:12:27','2023-07-04 07:12:27'),(26,4,'07-07-2023','07','07','2023','Absent','2023-07-04 07:12:27','2023-07-04 07:12:27'),(48,1,'08-07-2023','08','07','2023','Absent','2023-07-04 16:55:46','2023-07-04 16:55:46'),(49,2,'08-07-2023','08','07','2023','Absent','2023-07-04 16:55:46','2023-07-04 16:55:46'),(50,3,'08-07-2023','08','07','2023','Absent','2023-07-04 16:55:46','2023-07-04 16:55:46'),(51,4,'08-07-2023','08','07','2023','Absent','2023-07-04 16:55:46','2023-07-04 16:55:46'),(52,5,'08-07-2023','08','07','2023','Absent','2023-07-04 16:55:46','2023-07-04 16:55:46');
/*!40000 ALTER TABLE `attendances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `banner_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('show','hide') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'show',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
INSERT INTO `banners` VALUES (1,'The Best Organic Products Online','upload/banner/1769647176332299_banner.png','show','2023-06-25 04:24:21',NULL),(2,'Everyday Fresh & Clean With Our Products','upload/banner/1769647185216280_banner.png','show','2023-06-25 04:24:29',NULL),(3,'Make your Breakfast Healthy and Easy','upload/banner/1769647192479345_banner.png','show','2023-06-25 04:24:36',NULL);
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blog_category_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
INSERT INTO `blog_categories` VALUES (1,'Pet Foods','pet-foods','2023-06-25 09:44:09',NULL),(6,'Fresh Fruit','fresh-fruit','2023-07-10 14:19:23',NULL),(7,'Baking Material','baking-material','2023-07-10 14:19:31',NULL);
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blog_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_post_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blog_comments` WRITE;
/*!40000 ALTER TABLE `blog_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `post_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_short_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_long_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `views` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blog_posts` WRITE;
/*!40000 ALTER TABLE `blog_posts` DISABLE KEYS */;
INSERT INTO `blog_posts` VALUES (3,1,'I Tried 38 Different Bottles of Mustard — These Are the Ones I’ll Buy Again','i-tried-38-different-bottles-of-mustard-—-these-are-the-ones-i’ll-buy-again','upload/blog/1769667585655316.png','Lorem ipsum dolor sit, amet consectetur adipisicing elit. \r\nAnimi, quas veniam? Quisquam aliquid ipsum alias, ipsa quasi veritatis porro quidem, fuga deserunt magnam illum rem quod.','<p class=\"single-excerpt\">Helping everyone live happier, healthier lives at home through their kitchen. Kitchn is a daily food magazine on the Web celebrating life in the kitchen through home cooking and kitchen intelligence.</p>\r\n<p>We\'ve reviewed and ranked all of the best smartwatches on the market right now, and we\'ve made a definitive list of the top 10 devices you can buy today. One of the 10 picks below may just be your perfect next smartwatch.</p>\r\n<p>Those top-end wearables span from the Apple Watch to Fitbits, Garmin watches to Tizen-sporting Samsung watches. There\'s also Wear OS which is Google\'s own wearable operating system in the vein of Apple\'s watchOS - you&rsquo;ll see it show up in a lot of these devices.</p>\r\n<h5 class=\"mt-50\">Lorem ipsum dolor sit amet cons</h5>\r\n<p>Throughout our review process, we look at the design, features, battery life, spec, price and more for each smartwatch, rank it against the competition and enter it into the list you\'ll find below.</p>\r\n<p><img class=\"mb-30\" src=\"assets/imgs/blog/blog-21.png\" alt=\"\"></p>\r\n<p>Tortor, lobortis semper viverra ac, molestie tortor laoreet amet euismod et diam quis aliquam consequat porttitor integer a nisl, in faucibus nunc et aenean turpis dui dignissim nec scelerisque ullamcorper eu neque, augue quam quis lacus pretium eros est amet turpis nunc in turpis massa et eget facilisis ante molestie penatibus dolor volutpat, porta pellentesque scelerisque at ornare dui tincidunt cras feugiat tempor lectus</p>\r\n<blockquote>\r\n<p>Integer eu faucibus&nbsp;<a href=\"#\">dolor</a><sup><a href=\"#\">[5]</a></sup>. Ut venenatis tincidunt diam elementum imperdiet. Etiam accumsan semper nisl eu congue. Sed aliquam magna erat, ac eleifend lacus rhoncus in.</p>\r\n</blockquote>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet id enim, libero sit. Est donec lobortis cursus amet, cras elementum libero convallis feugiat. Nulla faucibus facilisi tincidunt a arcu, sem donec sed sed. Tincidunt morbi scelerisque lectus non. At leo mauris, vel augue. Facilisi diam consequat amet, commodo lorem nisl, odio malesuada cras. Tempus lectus sed libero viverra ut. Facilisi rhoncus elit sit sit.</p>',14,'2023-06-25 09:48:45','2023-07-10 02:53:47'),(8,7,'The Easy Italian Chicken Dinner I Make Over and Over Again','the-easy-italian-chicken-dinner-i-make-over-and-over-again','upload/blog/1771043657873732.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.','<p class=\"single-excerpt\">Helping everyone live happier, healthier lives at home through their kitchen. Kitchn is a daily food magazine on the Web celebrating life in the kitchen through home cooking and kitchen intelligence.</p>\r\n<p>We\'ve reviewed and ranked all of the best smartwatches on the market right now, and we\'ve made a definitive list of the top 10 devices you can buy today. One of the 10 picks below may just be your perfect next smartwatch.</p>\r\n<p>Those top-end wearables span from the Apple Watch to Fitbits, Garmin watches to Tizen-sporting Samsung watches. There\'s also Wear OS which is Google\'s own wearable operating system in the vein of Apple\'s watchOS - you&rsquo;ll see it show up in a lot of these devices.</p>\r\n<h5 class=\"mt-50\">Lorem ipsum dolor sit amet cons</h5>\r\n<p>Throughout our review process, we look at the design, features, battery life, spec, price and more for each smartwatch, rank it against the competition and enter it into the list you\'ll find below.</p>\r\n<p><img class=\"mb-30\" src=\"assets/imgs/blog/blog-21.png\" alt=\"\"></p>\r\n<p>Tortor, lobortis semper viverra ac, molestie tortor laoreet amet euismod et diam quis aliquam consequat porttitor integer a nisl, in faucibus nunc et aenean turpis dui dignissim nec scelerisque ullamcorper eu neque, augue quam quis lacus pretium eros est amet turpis nunc in turpis massa et eget facilisis ante molestie penatibus dolor volutpat, porta pellentesque scelerisque at ornare dui tincidunt cras feugiat tempor lectus</p>\r\n<blockquote>\r\n<p>Integer eu faucibus&nbsp;<a href=\"#\">dolor</a><sup><a href=\"#\">[5]</a></sup>. Ut venenatis tincidunt diam elementum imperdiet. Etiam accumsan semper nisl eu congue. Sed aliquam magna erat, ac eleifend lacus rhoncus in.</p>\r\n</blockquote>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet id enim, libero sit. Est donec lobortis cursus amet, cras elementum libero convallis feugiat. Nulla faucibus facilisi tincidunt a arcu, sem donec sed sed. Tincidunt morbi scelerisque lectus non. At leo mauris, vel augue. Facilisi diam consequat amet, commodo lorem nisl, odio malesuada cras. Tempus lectus sed libero viverra ut. Facilisi rhoncus elit sit sit.</p>',NULL,'2023-07-10 14:20:50',NULL),(9,6,'Best smartwatch 2022: the top wearables you can buy today','best-smartwatch-2022:-the-top-wearables-you-can-buy-today','upload/blog/1771043717813364.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.','<p class=\"single-excerpt\">Helping everyone live happier, healthier lives at home through their kitchen. Kitchn is a daily food magazine on the Web celebrating life in the kitchen through home cooking and kitchen intelligence.</p>\r\n<p>We\'ve reviewed and ranked all of the best smartwatches on the market right now, and we\'ve made a definitive list of the top 10 devices you can buy today. One of the 10 picks below may just be your perfect next smartwatch.</p>\r\n<p>Those top-end wearables span from the Apple Watch to Fitbits, Garmin watches to Tizen-sporting Samsung watches. There\'s also Wear OS which is Google\'s own wearable operating system in the vein of Apple\'s watchOS - you&rsquo;ll see it show up in a lot of these devices.</p>\r\n<h5 class=\"mt-50\">Lorem ipsum dolor sit amet cons</h5>\r\n<p>Throughout our review process, we look at the design, features, battery life, spec, price and more for each smartwatch, rank it against the competition and enter it into the list you\'ll find below.</p>',NULL,'2023-07-10 14:21:47',NULL),(10,1,'9 Tasty Ideas That Will Inspire You to Grow a Home Herb Garden Today','9-tasty-ideas-that-will-inspire-you-to-grow-a-home-herb-garden-today','upload/blog/1771043757006279.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.','<p class=\"single-excerpt\">Helping everyone live happier, healthier lives at home through their kitchen. Kitchn is a daily food magazine on the Web celebrating life in the kitchen through home cooking and kitchen intelligence.</p>\r\n<p>We\'ve reviewed and ranked all of the best smartwatches on the market right now, and we\'ve made a definitive list of the top 10 devices you can buy today. One of the 10 picks below may just be your perfect next smartwatch.</p>\r\n<p>Those top-end wearables span from the Apple Watch to Fitbits, Garmin watches to Tizen-sporting Samsung watches. There\'s also Wear OS which is Google\'s own wearable operating system in the vein of Apple\'s watchOS - you&rsquo;ll see it show up in a lot of these devices.</p>\r\n<h5 class=\"mt-50\">Lorem ipsum dolor sit amet cons</h5>\r\n<p>Throughout our review process, we look at the design, features, battery life, spec, price and more for each smartwatch, rank it against the competition and enter it into the list you\'ll find below.</p>',NULL,'2023-07-10 14:22:24',NULL);
/*!40000 ALTER TABLE `blog_posts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_brand_name_unique` (`brand_name`),
  UNIQUE KEY `brands_brand_email_unique` (`brand_email`),
  UNIQUE KEY `brands_brand_phone_unique` (`brand_phone`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'PEPSI','pepsi','upload/brand/1770565804964040_brand.png','pepsi@gmail.com','0722334455','Number 930, Hoang Anh Gia Lai Apartment Block, Nguyen Thi Thap Street, District 7, Ho Chi Minh City','2023-06-25 03:28:46','2023-07-10 09:10:29'),(2,'OREO','oreo','upload/brand/1769937386676275_brand.png','oreo@gmail.com','0344332211','No. 9128, 8th floor, Vinsmart city apartment, Nam Tu Liem district, Hanoi','2023-06-28 09:17:07','2023-07-11 05:53:08'),(3,'COCA COLA','coca-cola','upload/brand/1770945723186964_brand.png','cocacola@gmai.com','0912345678','Room No.8, Keangnam Building, Pham Hung Street, Nam Tu Liem District, Ha Noi City','2023-06-30 04:14:21','2023-07-10 09:10:01'),(4,'ORGANICFOOD','organicfood','upload/brand/1770859603425982_brand.jpg','organicfood@gmail.com','0932060314','13, Road No. 10, Binh Chanh District','2023-07-08 13:35:21','2023-07-11 05:52:25'),(5,'FOOD','food','upload/brand/1770862313961324_brand.png','Food@gmail.com','0934060314','19, Road No. 10, Binh Chanh District, Ho Chi Minh city','2023-07-08 14:18:15','2023-07-10 09:09:48'),(6,'KITKAT','kitkat','upload/brand/1771024064775703_brand.png','kitkat@gmail.com','0336622122','Number 930, Hoang Anh Gia Lai Apartment Block, Nguyen Thi Thap Street, District 7, Ho Chi Minh City','2023-07-10 09:09:24','2023-07-11 05:52:46');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_category_name_unique` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'VEGETABLE','vegetable','upload/category/1769644191460967_category.svg','2023-06-25 03:36:54','2023-06-25 03:36:54'),(2,'FRUIT','fruit','upload/category/1769644295037590_category.svg','2023-06-25 03:38:33','2023-06-25 03:38:33'),(3,'SEAFOOD','seafood','upload/category/1770563457266912_category.svg','2023-06-25 03:40:01','2023-07-05 07:08:14'),(4,'SOFT DRINK','soft-drink','upload/category/1769644485532351_category.svg','2023-06-25 03:41:35','2023-07-09 12:49:21'),(5,'PET FOODS','pet-foods','upload/category/1769644645213784_category.svg','2023-06-25 03:44:07','2023-06-25 03:44:07'),(6,'CAKE','cake','upload/category/1769644789812491_category.svg','2023-06-25 03:46:25','2023-06-25 03:46:25'),(7,'EGGS','eggs','upload/category/1770565105826310_category.svg','2023-06-25 03:47:19','2023-07-05 07:34:27');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `compares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compares` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `compares` WRITE;
/*!40000 ALTER TABLE `compares` DISABLE KEYS */;
INSERT INTO `compares` VALUES (10,3,40,'2023-07-12 02:42:54',NULL);
/*!40000 ALTER TABLE `compares` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coupon_discount` int(11) NOT NULL,
  `coupon_validity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupons_coupon_code_unique` (`coupon_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES (1,'NEST',35,'2024-05-07',1,'2023-06-25 04:28:55','2023-07-05 07:55:53'),(2,'NESTSHOP23',40,'2023-07-31',1,'2023-06-25 07:28:21','2023-07-05 07:50:39'),(3,'TESTCOUPON',45,'2023-07-31',1,'2023-07-05 07:49:52',NULL);
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experience` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_employee_code_unique` (`employee_code`),
  UNIQUE KEY `employees_employee_email_unique` (`employee_email`),
  UNIQUE KEY `employees_employee_phone_unique` (`employee_phone`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'NEST100','Ngo Vinh Thong','ngovinhthong070802@gmail.com','0775083541','246, street 8, Ward 6, Vo Gap district, Ho Chi Minh city','upload/employee_images/1770180734115848_employee.png','Accountant','1 Year','2000','2023-07-01 01:45:01',NULL),(2,'NEST101','Le Hoang Tuan','lehoangtuan051102@gmail.com','0902085056','No. 13, lane 118, alley 21, Nguyen Ngoc Vu street, Ba Dinh ward, Hanoi','upload/employee_images/1770182370065085_employee.png','Shipper','0 Year','1000','2023-07-01 02:11:01',NULL),(3,'NEST102','Nguyen Van A','nguyenvana@gmail.com','0779877899','Sailing Tower, 111A Pasteur Street, District 1, Ho Chi Minh City','upload/employee_images/1770205046558407_employee.png','Shipper','3 Years','3000','2023-07-01 08:11:27','2023-07-01 14:27:21'),(4,'NEST103','Nguyen Van B','nguyenvanb@gmail.com','0456987123','No. 13, lane 118, alley 21, Nguyen Ngoc Vu street, Ba Dinh ward, Hanoi','upload/employee_images/1770472887199406_employee.png','HRM','1 Year','1200','2023-07-04 07:08:40',NULL),(5,'NEST104','Nguyen Van C','nguyenvanc@gmail.com','0775089632','246, street 8, Ward 6, Vo Gap district, Ho Chi Minh city','upload/employee_images/1770499163562101_employee.png','Shipper','1 Year','1000','2023-07-04 14:06:19',NULL);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_05_02_184500_create_brands_table',2),(6,'2023_05_04_094822_create_categories_table',3),(7,'2023_05_05_010505_create_sub_categories_table',3),(8,'2023_05_09_160008_create_products_table',4),(9,'2023_05_09_161259_create_multi_images_table',4),(10,'2023_05_15_074747_create_sliders_table',5),(11,'2023_05_15_100021_create_banners_table',5),(12,'2023_05_27_063309_create_wishlists_table',6),(13,'2023_05_29_141018_create_compares_table',7),(14,'2023_06_03_082224_create_coupons_table',8),(15,'2023_06_03_133542_create_ship_cities_table',9),(16,'2023_06_03_133911_create_ship_districts_table',9),(17,'2023_06_03_134047_create_ship_communes_table',9),(20,'2023_06_18_105634_create_blog_posts_table',10),(21,'2023_06_18_151251_create_blog_categories_table',10),(22,'2023_06_19_114428_create_blog_comments_table',10),(23,'2023_06_20_205544_create_reviews_table',11),(24,'2023_06_21_222234_create_site_settings_table',12),(25,'2023_06_22_074303_create_seos_table',13),(26,'2023_06_24_082558_create_permission_tables',14),(35,'2023_06_06_210147_create_orders_table',15),(36,'2023_06_06_211501_create_order_details_table',15),(37,'2023_06_27_211102_create_notifications_table',16),(48,'2023_06_30_182951_create_advance_salaries_table',18),(49,'2023_06_30_200817_create_pay_salaries_table',19),(50,'2023_06_30_133652_create_employees_table',17),(52,'2023_07_01_221855_create_smtp_settings_table',21),(53,'2023_07_01_092824_create_attendances_table',20),(56,'2023_07_03_113421_create_received_mails_table',22),(57,'2023_07_03_195643_create_subscribers_table',23);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(2,'App\\Models\\User',4);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `multi_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `photo_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `multi_images` WRITE;
/*!40000 ALTER TABLE `multi_images` DISABLE KEYS */;
INSERT INTO `multi_images` VALUES (19,10,'upload/products/multiple_images/1769937510319194_product.jpg','2023-06-28 09:19:05',NULL),(20,10,'upload/products/multiple_images/1769937510562920_product.jpg','2023-06-28 09:19:05',NULL),(30,9,'upload/products/multiple_images/1770662030486351_product.jpg','2023-07-06 09:15:01',NULL),(33,7,'upload/products/multiple_images/1770662139105313_product.jpg','2023-07-06 09:16:45',NULL),(34,10,'upload/products/multiple_images/1770856735040091_product.jpg','2023-07-08 12:49:46',NULL),(35,10,'upload/products/multiple_images/1770856853618261_product.jpg','2023-07-08 12:51:39',NULL),(37,12,'upload/products/multiple_images/1770858330428794_product.jpg','2023-07-08 13:15:07',NULL),(38,13,'upload/products/multiple_images/1770858742313948_product.jpg','2023-07-08 13:21:40',NULL),(39,14,'upload/products/multiple_images/1770858982209744_product.jpg','2023-07-08 13:25:29',NULL),(40,15,'upload/products/multiple_images/1770859413959124_product.jpg','2023-07-08 13:32:21',NULL),(41,16,'upload/products/multiple_images/1770859849933160_product.jpg','2023-07-08 13:39:17',NULL),(42,17,'upload/products/multiple_images/1770860067856012_product.jpg','2023-07-08 13:42:44',NULL),(43,18,'upload/products/multiple_images/1770860304965583_product.jpg','2023-07-08 13:46:31',NULL),(44,19,'upload/products/multiple_images/1770860661875608_product.jpg','2023-07-08 13:52:11',NULL),(45,20,'upload/products/multiple_images/1770861350202841_product.jpg','2023-07-08 14:03:07',NULL),(46,21,'upload/products/multiple_images/1770861555295148_product.jpg','2023-07-08 14:06:23',NULL),(47,22,'upload/products/multiple_images/1770861736600191_product.jpg','2023-07-08 14:09:16',NULL),(48,23,'upload/products/multiple_images/1770862037881701_product.jpg','2023-07-08 14:14:03',NULL),(49,24,'upload/products/multiple_images/1770862502455399_product.jpg','2023-07-08 14:21:26',NULL),(50,25,'upload/products/multiple_images/1770862973400744_product.jpg','2023-07-08 14:28:55',NULL),(51,26,'upload/products/multiple_images/1770863241370443_product.jpg','2023-07-08 14:33:11',NULL),(52,27,'upload/products/multiple_images/1770863699440575_product.jpg','2023-07-08 14:40:28',NULL),(53,28,'upload/products/multiple_images/1770864052440648_product.jpg','2023-07-08 14:46:04',NULL),(54,29,'upload/products/multiple_images/1770864412485060_product.jpg','2023-07-08 14:51:48',NULL),(55,30,'upload/products/multiple_images/1770864602947930_product.jpg','2023-07-08 14:54:49',NULL),(56,31,'upload/products/multiple_images/1770866620943260_product.jpg','2023-07-08 15:26:54',NULL),(57,32,'upload/products/multiple_images/1770868933409409_product.jpg','2023-07-08 16:03:39',NULL),(58,33,'upload/products/multiple_images/1770869250224143_product.jpg','2023-07-08 16:08:41',NULL),(59,34,'upload/products/multiple_images/1770869571854514_product.jpg','2023-07-08 16:13:48',NULL),(60,35,'upload/products/multiple_images/1770952592792527_product.jpg','2023-07-09 14:13:23',NULL),(61,35,'upload/products/multiple_images/1770952593037999_product.jpg','2023-07-09 14:13:23',NULL),(62,36,'upload/products/multiple_images/1770952696913598_product.jpg','2023-07-09 14:15:02',NULL),(63,36,'upload/products/multiple_images/1770952697163282_product.jpg','2023-07-09 14:15:03',NULL),(68,40,'upload/products/multiple_images/1771000267066363_product.jpg','2023-07-10 02:51:09',NULL),(69,41,'upload/products/multiple_images/1771182415996360_product.jpg','2023-07-12 03:06:19',NULL);
/*!40000 ALTER TABLE `multi_images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('0c387cb9-434c-4e84-98e4-1cc5c1d0222e','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-11 08:43:39','2023-07-11 08:43:39'),('0e91f307-deae-4776-af35-75d092be90a9','App\\Notifications\\NewBlogCommentNotification','App\\Models\\User',4,'{\"message\":\"New comment on blog post\",\"type\":\"new_blog_comment\"}',NULL,0,'2023-07-09 14:02:45','2023-07-09 14:02:45'),('18de07ea-9dbd-4d5d-8104-7e04dc4cd0de','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',1,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}','2023-07-12 03:13:24',1,'2023-07-12 03:10:29','2023-07-12 03:13:24'),('2692f035-12a3-4143-88e3-0f71ee3dbf62','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',10,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-05 03:52:26','2023-07-05 03:52:26'),('2ec9c5c9-e055-4240-8d1e-ce7f463c910c','App\\Notifications\\NewBlogCommentNotification','App\\Models\\User',4,'{\"message\":\"New comment on blog post\",\"type\":\"new_blog_comment\"}',NULL,0,'2023-07-09 13:37:51','2023-07-09 13:37:51'),('2fbcc9cb-fc80-4fd8-adfc-5afa1f814607','App\\Notifications\\NewReviewNotification','App\\Models\\User',4,'{\"message\":\"There is a new product review\",\"type\":\"new_review_product\"}',NULL,0,'2023-07-09 15:26:16','2023-07-09 15:26:16'),('3d9abe45-79ca-4c7b-84ab-94118f047a9f','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',1,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}','2023-07-12 03:20:52',1,'2023-07-12 03:19:35','2023-07-12 03:20:52'),('434fe8ce-59a4-4fd0-ad11-043c3f7d0f05','App\\Notifications\\VendorDisapproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been disapproved\",\"type\":\"vendor_disapprove\"}','2023-07-05 04:38:53',1,'2023-07-05 04:38:24','2023-07-05 04:38:53'),('48435d7b-a631-49ce-8fcb-6edc0f73763e','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-05 03:52:26','2023-07-05 03:55:59'),('48cfbb45-bc22-4dbc-affd-e31cf9ba6deb','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-11 08:43:45','2023-07-11 08:43:45'),('49827a86-30fb-4c74-91a5-ce3b67790c26','App\\Notifications\\UserRegisterNotification','App\\Models\\User',4,'{\"message\":\"A new account registered\",\"type\":\"new_customer\"}',NULL,0,'2023-07-11 08:33:42','2023-07-11 08:33:42'),('49c4f2a2-63f7-41f7-afe9-d413e1e5038a','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-10 03:03:38','2023-07-10 03:03:38'),('49fd9da9-6fb2-455d-a89e-47d800cea60d','App\\Notifications\\NewReviewNotification','App\\Models\\User',1,'{\"message\":\"There is a new product review\",\"type\":\"new_review_product\"}','2023-07-11 14:46:26',1,'2023-07-11 14:45:46','2023-07-11 14:46:26'),('5214d777-d523-4147-b0c6-20e49edc6a1c','App\\Notifications\\CancelOrderNotification','App\\Models\\User',4,'{\"message\":\"A request to cancel the order\",\"type\":\"cancel_order\"}',NULL,0,'2023-07-11 12:55:58','2023-07-11 12:55:58'),('5c750abf-0a9f-4c81-9b9d-09dc8b08c995','App\\Notifications\\UserRegisterNotification','App\\Models\\User',4,'{\"message\":\"A new account registered\",\"type\":\"new_customer\"}',NULL,0,'2023-07-10 13:51:23','2023-07-10 13:51:23'),('5d79e67d-50df-4a6f-84af-298a6728e4a4','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-12 03:19:35','2023-07-12 03:19:35'),('6034c12d-e353-4567-aa9a-132570f52cfa','App\\Notifications\\NewReviewNotification','App\\Models\\User',4,'{\"message\":\"There is a new product review\",\"type\":\"new_review_product\"}',NULL,0,'2023-07-07 07:11:03','2023-07-07 07:11:03'),('644c0534-1160-4f20-97bb-0f55507e0b96','App\\Notifications\\NewReviewNotification','App\\Models\\User',4,'{\"message\":\"There is a new product review\",\"type\":\"new_review_product\"}',NULL,0,'2023-07-11 09:02:22','2023-07-11 09:02:22'),('65e6545a-b4a2-43e4-b321-65d804cbc8d4','App\\Notifications\\VendorApproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been approved\",\"type\":\"vendor_approve\"}','2023-07-05 04:37:09',1,'2023-07-05 02:24:02','2023-07-05 04:37:09'),('81a6bc53-d36d-40b8-b844-96e66897870d','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-12 03:10:29','2023-07-12 03:10:29'),('843e4f78-086a-4359-9426-cc878773e697','App\\Notifications\\VendorApproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been approved\",\"type\":\"vendor_approve\"}',NULL,0,'2023-07-11 06:24:15','2023-07-11 06:24:15'),('84f251bc-7dfe-4320-b9e6-54b8b93ec720','App\\Notifications\\VendorApproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been approved\",\"type\":\"vendor_approve\"}','2023-07-05 04:37:09',1,'2023-07-05 02:24:18','2023-07-05 04:37:09'),('8c8af4bb-55e8-46cd-aaee-f85e714c48f5','App\\Notifications\\VendorDisapproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been disapproved\",\"type\":\"vendor_disapprove\"}','2023-07-05 04:37:09',1,'2023-07-05 02:24:11','2023-07-05 04:37:09'),('8d6e802c-1c01-42ac-8b43-dbb963b7d30f','App\\Notifications\\VendorDisapproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been disapproved\",\"type\":\"vendor_disapprove\"}','2023-07-05 04:37:09',1,'2023-07-05 04:14:37','2023-07-05 04:37:09'),('b105c8e0-552d-4cad-962d-c02c188d9a48','App\\Notifications\\VendorDisapproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been disapproved\",\"type\":\"vendor_disapprove\"}',NULL,0,'2023-07-11 06:23:11','2023-07-11 06:23:11'),('b991d626-b5c0-4c67-9568-de3c444ee89e','App\\Notifications\\VendorApproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been approved\",\"type\":\"vendor_approve\"}','2023-07-05 06:56:27',1,'2023-07-05 06:55:25','2023-07-05 06:56:27'),('c7f4c3cf-a6c1-4199-84e4-53dc998e9ec1','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-11 12:37:36','2023-07-11 12:37:36'),('cabba3fb-d999-48c2-a0ec-185195c33c34','App\\Notifications\\ReturnOrderNotification','App\\Models\\User',4,'{\"message\":\"A request to return the order\",\"type\":\"return_order\"}',NULL,0,'2023-07-11 08:57:02','2023-07-11 08:57:02'),('cc605b45-d91d-475b-88db-be401d900297','App\\Notifications\\NewReviewNotification','App\\Models\\User',10,'{\"message\":\"There is a new product review\",\"type\":\"new_review_product\"}',NULL,0,'2023-07-07 07:11:03','2023-07-07 07:11:03'),('d3aaad0b-a051-4460-ac7b-3373bf1e2cfb','App\\Notifications\\CancelOrderNotification','App\\Models\\User',4,'{\"message\":\"A request to cancel the order\",\"type\":\"cancel_order\"}',NULL,0,'2023-07-11 08:50:24','2023-07-11 08:50:24'),('d483dec3-55e8-4596-88bd-6f707892d087','App\\Notifications\\NewBlogCommentNotification','App\\Models\\User',4,'{\"message\":\"New comment on blog post\",\"type\":\"new_blog_comment\"}',NULL,0,'2023-07-09 13:41:36','2023-07-09 13:41:36'),('d5443f0d-bc44-43c4-9342-b5a3ba82f088','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-11 08:41:02','2023-07-11 08:41:02'),('d6ab571d-8035-4f46-9d67-ed0669bea898','App\\Notifications\\VendorApproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been approved\",\"type\":\"vendor_approve\"}','2023-07-05 04:37:09',1,'2023-07-05 04:19:10','2023-07-05 04:37:09'),('e50af667-cbb0-41e7-80d8-19841e74892e','App\\Notifications\\NewReviewNotification','App\\Models\\User',4,'{\"message\":\"There is a new product review\",\"type\":\"new_review_product\"}',NULL,0,'2023-07-11 14:45:46','2023-07-11 14:45:46'),('f67da152-fa6d-4248-a0d7-6813137e8350','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-11 08:54:02','2023-07-11 08:54:02'),('f8724508-498f-40c7-bea8-d7acfdbcf6fd','App\\Notifications\\ReturnOrderNotification','App\\Models\\User',4,'{\"message\":\"A request to return the order\",\"type\":\"return_order\"}',NULL,0,'2023-07-11 12:52:44','2023-07-11 12:52:44'),('ff389256-ca33-47ad-9f32-03aba34f3ed2','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\",\"type\":\"new_order\"}',NULL,0,'2023-07-11 06:38:32','2023-07-11 06:38:32');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `price` double(8,2) NOT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_details_order_id_foreign` (`order_id`),
  CONSTRAINT `order_details_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_details` WRITE;
/*!40000 ALTER TABLE `order_details` DISABLE KEYS */;
INSERT INTO `order_details` VALUES (1,1,4,28,2.00,'1','2023-07-10 03:03:28',NULL),(2,1,4,27,15.00,'1','2023-07-10 03:03:28',NULL),(3,1,4,26,1.00,'1','2023-07-10 03:03:28',NULL),(4,1,4,29,32.00,'1','2023-07-10 03:03:28',NULL),(5,1,4,30,15.00,'1','2023-07-10 03:03:28',NULL),(6,2,4,26,20.00,'1','2023-07-11 06:38:26',NULL),(7,2,4,27,15.00,'1','2023-07-11 06:38:26',NULL),(8,2,4,28,2.00,'1','2023-07-11 06:38:26',NULL),(9,2,4,40,26.00,'1','2023-07-11 06:38:26',NULL),(10,3,5,34,9.00,'1','2023-07-11 08:40:55',NULL),(11,3,1,33,3.00,'4','2023-07-11 08:40:55',NULL),(12,3,4,32,22.00,'1','2023-07-11 08:40:55',NULL),(13,4,4,40,26.00,'1','2023-07-11 08:43:34',NULL),(14,4,5,34,9.00,'1','2023-07-11 08:43:34',NULL),(15,5,4,40,26.00,'1','2023-07-11 08:43:40',NULL),(16,5,5,34,9.00,'1','2023-07-11 08:43:40',NULL),(17,6,4,40,26.00,'20','2023-07-11 08:53:57',NULL),(18,7,4,40,26.00,'10','2023-07-11 12:37:32',NULL),(19,9,1,41,20.00,'10','2023-07-12 03:10:25',NULL),(20,10,1,31,8.00,'5','2023-07-12 03:19:26',NULL),(21,10,4,30,15.00,'2','2023-07-12 03:19:26',NULL),(22,10,4,29,32.00,'2','2023-07-12 03:19:26',NULL),(23,10,4,28,2.00,'3','2023-07-12 03:19:26',NULL),(24,10,4,27,15.00,'3','2023-07-12 03:19:26',NULL);
/*!40000 ALTER TABLE `order_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `commune_id` bigint(20) unsigned NOT NULL,
  `post_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(8,2) NOT NULL,
  `discount` double(8,2) DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_day` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_month` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmed_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processing_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picked_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipped_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_day` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancel_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancel_order_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `return_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_order_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,3,'Minh Kiet','laiminhkiet0705200202@gmail.com','0793442309','No 7, T14 Street',1,13,9,'738010','note','Cash On Delivery','Cash On Delivery',NULL,'1771001042491961','NFS1017324302',42.25,22.75,'usd','10-07-2023 10:03:28','10','07','2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11-07-2023 19:55:55','1',NULL,NULL,'0','pending','2023-07-10 03:03:28','2023-07-11 12:55:55'),(2,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,2,'738010','note','Cash On Delivery','Cash On Delivery',NULL,'1771105163439074','NFS1188760767',63.00,0.00,'usd','11-07-2023 13:38:26','11','07','2023','11-07-2023 19:52:13','11-07-2023 19:52:16',NULL,NULL,'11-07-2023 19:52:19','11','07','2023',NULL,'0','11-07-2023 19:52:40','Broken Product','2','delivered','2023-07-11 06:38:26','2023-07-11 12:53:57'),(3,18,'Hoang Phuc','hoangphuc270502@gmail.com','0332964321','14',1,13,9,'70800','note','Paypal Payment','Credit Card','34L940811S4009633','1771112870161505','NFS3984851012',27.95,15.05,'usd','11-07-2023 15:40:55','11','07','2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'0','pending','2023-07-11 08:40:55',NULL),(4,18,'Hoang Phuc','hoangphuc270502@gmail.com','0332964321','14',1,20,95,'79800','noet1','Stripe Payment','Credit Card','cs_test_a139KrtsWFqgslMyliV7qm8BtT2xKgPrHp6vn9EgV1nAusRcYnwyjNqB9d','1771113033333862','NFS9516951181',35.00,0.00,'usd','11-07-2023 15:43:34','11','07','2023','11-07-2023 20:28:05','11-07-2023 20:28:15',NULL,NULL,'11-07-2023 20:28:19','11','07','2023',NULL,'0',NULL,NULL,'0','delivered','2023-07-11 08:43:34','2023-07-11 13:28:19'),(5,18,'Hoang Phuc','hoangphuc270502@gmail.com','0332964321','14',1,20,95,'79800','noet1','Stripe Payment','Credit Card','cs_test_a1ubdgscqSaJYMLei14Lhs7S25amwiWl4GwpYsi4Tyfb42fkBFQBB5MbBg','1771113041813915','NFS3102892934',35.00,0.00,'usd','11-07-2023 15:43:40','11','07','2023','11-07-2023 15:48:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11-07-2023 15:50:20','2',NULL,NULL,'0','confirmed','2023-07-11 08:43:40','2023-07-11 08:51:05'),(6,18,'Hoang Phuc','hoangphuc270502@gmail.com','0332964321','15',1,25,47,'79800',NULL,'Cash On Delivery','Cash On Delivery',NULL,'1771113690166764','NFS2978534736',520.00,0.00,'usd','11-07-2023 15:53:57','11','07','2023','11-07-2023 15:56:07','11-07-2023 15:56:12',NULL,NULL,'11-07-2023 15:56:16','11','07','2023',NULL,'0','11-07-2023 15:56:58','broken','2','delivered','2023-07-11 08:53:57','2023-07-11 08:57:36'),(7,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,3,'738010','note','Cash On Delivery','Cash On Delivery',NULL,'1771127756337978','NFS7897831008',260.00,0.00,'usd','11-07-2023 19:37:32','11','07','2023','11-07-2023 19:51:07','11-07-2023 19:51:24',NULL,NULL,'11-07-2023 19:51:41','11','07','2023',NULL,'0',NULL,NULL,'0','delivered','2023-07-11 12:37:32','2023-07-11 12:51:41'),(8,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,20,95,'738010','notes','Paypal Payment','Credit Card','7S09660177957304W','1771182530627307','NFS7639083783',130.00,70.00,'usd','12-07-2023 10:08:09','12','07','2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'0','pending','2023-07-12 03:08:09',NULL),(9,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,20,95,'738010','notes','Paypal Payment','Credit Card','7LG81298YL987032W','1771182673438451','NFS1710251926',130.00,70.00,'usd','12-07-2023 10:10:25','12','07','2023','12-07-2023 10:14:50','12-07-2023 10:15:22',NULL,NULL,'12-07-2023 10:16:10','12','07','2023',NULL,'0',NULL,NULL,'0','delivered','2023-07-12 03:10:25','2023-07-12 03:16:10'),(10,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,1,31,'738010','notes','Stripe Payment','Credit Card','cs_test_a1aVh8KU6PzuKH9dAjCUEGPJdi8WiEaXpNEQyPq5vh9wzLGpPd5DU2s2pY','1771183239828820','NFS3514785959',185.00,0.00,'usd','12-07-2023 10:19:26','12','07','2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'0','pending','2023-07-12 03:19:26',NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pay_salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_salaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `salary_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `advance_salary` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_salary` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pay_salaries` WRITE;
/*!40000 ALTER TABLE `pay_salaries` DISABLE KEYS */;
INSERT INTO `pay_salaries` VALUES (1,1,'July','2023','2000','0','2000','2023-07-01 01:52:23',NULL),(2,2,'July','2023','1000','0','1000','2023-07-02 04:01:39',NULL),(3,4,'July','2023','1200','500','700','2023-07-04 07:09:39',NULL),(4,5,'July','2023','1000','500','500','2023-07-04 14:08:53',NULL),(5,3,'July','2023','3000','0','3000','2023-07-04 16:48:59',NULL);
/*!40000 ALTER TABLE `pay_salaries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'brand.menu','web','brand','2023-07-12 03:31:24','2023-07-12 03:31:24'),(2,'brand.list','web','brand','2023-07-12 03:31:24','2023-07-12 03:31:24'),(3,'brand.add','web','brand','2023-07-12 03:31:24','2023-07-12 03:31:24'),(4,'brand.edit','web','brand','2023-07-12 03:31:24','2023-07-12 03:31:24'),(5,'brand.delete','web','brand','2023-07-12 03:31:24','2023-07-12 03:31:24'),(6,'category.menu','web','category','2023-07-12 03:31:24','2023-07-12 03:31:24'),(7,'category.list','web','category','2023-07-12 03:31:24','2023-07-12 03:31:24'),(8,'category.add','web','category','2023-07-12 03:31:24','2023-07-12 03:31:24'),(9,'category.edit','web','category','2023-07-12 03:31:24','2023-07-12 03:31:24'),(10,'category.delete','web','category','2023-07-12 03:31:24','2023-07-12 03:31:24'),(11,'subcategory.menu','web','subcategory','2023-07-12 03:31:24','2023-07-12 03:31:24'),(12,'subcategory.list','web','subcategory','2023-07-12 03:31:24','2023-07-12 03:31:24'),(13,'subcategory.add','web','subcategory','2023-07-12 03:31:24','2023-07-12 03:31:24'),(14,'subcategory.edit','web','subcategory','2023-07-12 03:31:24','2023-07-12 03:31:24'),(15,'subcategory.delete','web','subcategory','2023-07-12 03:31:24','2023-07-12 03:31:24'),(16,'product.menu','web','product','2023-07-12 03:31:24','2023-07-12 03:31:24'),(17,'product.list','web','product','2023-07-12 03:31:24','2023-07-12 03:31:24'),(18,'product.add','web','product','2023-07-12 03:31:24','2023-07-12 03:31:24'),(19,'product.edit','web','product','2023-07-12 03:31:24','2023-07-12 03:31:24'),(20,'product.delete','web','product','2023-07-12 03:31:24','2023-07-12 03:31:24'),(21,'product.restore','web','product','2023-07-12 03:31:24','2023-07-12 03:31:24'),(22,'inventory.menu','web','inventory','2023-07-12 03:31:24','2023-07-12 03:31:24'),(23,'slider.menu','web','slider','2023-07-12 03:31:24','2023-07-12 03:31:24'),(24,'slider.list','web','slider','2023-07-12 03:31:24','2023-07-12 03:31:24'),(25,'slider.add','web','slider','2023-07-12 03:31:24','2023-07-12 03:31:24'),(26,'slider.edit','web','slider','2023-07-12 03:31:24','2023-07-12 03:31:24'),(27,'slider.delete','web','slider','2023-07-12 03:31:24','2023-07-12 03:31:24'),(28,'banner.menu','web','banner','2023-07-12 03:31:24','2023-07-12 03:31:24'),(29,'banner.list','web','banner','2023-07-12 03:31:24','2023-07-12 03:31:24'),(30,'banner.add','web','banner','2023-07-12 03:31:24','2023-07-12 03:31:24'),(31,'banner.edit','web','banner','2023-07-12 03:31:24','2023-07-12 03:31:24'),(32,'banner.delete','web','banner','2023-07-12 03:31:24','2023-07-12 03:31:24'),(33,'coupon.menu','web','coupon','2023-07-12 03:31:24','2023-07-12 03:31:24'),(34,'coupon.list','web','coupon','2023-07-12 03:31:24','2023-07-12 03:31:24'),(35,'coupon.add','web','coupon','2023-07-12 03:31:24','2023-07-12 03:31:24'),(36,'coupon.edit','web','coupon','2023-07-12 03:31:24','2023-07-12 03:31:24'),(37,'coupon.delete','web','coupon','2023-07-12 03:31:24','2023-07-12 03:31:24'),(38,'shipping.area.menu','web','shipping area','2023-07-12 03:31:24','2023-07-12 03:31:24'),(39,'order.menu','web','order','2023-07-12 03:31:24','2023-07-12 03:31:24'),(40,'return.order.menu','web','return order','2023-07-12 03:31:24','2023-07-12 03:31:24'),(41,'cancel.order.menu','web','cancel order','2023-07-12 03:31:24','2023-07-12 03:31:24'),(42,'report.order.menu','web','report order','2023-07-12 03:31:24','2023-07-12 03:31:24'),(43,'contact.menu','web','contact','2023-07-12 03:31:24','2023-07-12 03:31:24'),(44,'blog.menu','web','blog','2023-07-12 03:31:24','2023-07-12 03:31:24'),(45,'review.menu','web','review','2023-07-12 03:31:24','2023-07-12 03:31:24'),(46,'setting.menu','web','setting','2023-07-12 03:31:24','2023-07-12 03:31:24'),(47,'subscriber.menu','web','subscriber','2023-07-12 03:31:24','2023-07-12 03:31:24'),(48,'roles.permissions.menu','web','roles and permissions','2023-07-12 03:31:24','2023-07-12 03:31:24'),(49,'admin.user.account.menu','web','admin user account','2023-07-12 03:31:24','2023-07-12 03:31:24'),(50,'user.management.menu','web','user management','2023-07-12 03:31:24','2023-07-12 03:31:24'),(51,'employee.menu','web','employee','2023-07-12 03:31:24','2023-07-12 03:31:24'),(52,'employee.list','web','employee','2023-07-12 03:31:24','2023-07-12 03:31:24'),(53,'employee.add','web','employee','2023-07-12 03:31:24','2023-07-12 03:31:24'),(54,'employee.edit','web','employee','2023-07-12 03:31:24','2023-07-12 03:31:24'),(55,'employee.delete','web','employee','2023-07-12 03:31:24','2023-07-12 03:31:24'),(56,'employee.salary.menu','web','employee salary','2023-07-12 03:31:24','2023-07-12 03:31:24'),(57,'employee.salary.list','web','employee salary','2023-07-12 03:31:24','2023-07-12 03:31:24'),(58,'employee.salary.add','web','employee salary','2023-07-12 03:31:24','2023-07-12 03:31:24'),(59,'employee.salary.edit','web','employee salary','2023-07-12 03:31:24','2023-07-12 03:31:24'),(60,'employee.salary.delete','web','employee salary','2023-07-12 03:31:24','2023-07-12 03:31:24'),(61,'employee.pay.salary','web','employee salary','2023-07-12 03:31:24','2023-07-12 03:31:24'),(62,'employee.search.pay.salary.by.month','web','employee salary','2023-07-12 03:31:24','2023-07-12 03:31:24'),(63,'timekeeping.menu','web','timekeeping','2023-07-12 03:31:24','2023-07-12 03:31:24'),(64,'timekeeping.by.day','web','timekeeping','2023-07-12 03:31:24','2023-07-12 03:31:24'),(65,'timekeeping.by.month','web','timekeeping','2023-07-12 03:31:24','2023-07-12 03:31:24'),(66,'database.backup','web','database backup','2023-07-12 03:31:24','2023-07-12 03:31:24');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `product_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_weight` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_measure` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_dimensions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturing_date` timestamp NULL DEFAULT NULL,
  `expiry_date` timestamp NULL DEFAULT NULL,
  `selling_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hot_deals` int(11) DEFAULT NULL,
  `featured` int(11) DEFAULT NULL,
  `special_offer` int(11) DEFAULT NULL,
  `special_deals` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_product_code_unique` (`product_code`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (7,1,2,17,'11117','Watermelon 2.3kg or more','watermelon-2.3kg-or-more','upload/products/thumbnail/1770857820766929_product_thumbnail.jpg','91','new product','2','kilogam',NULL,'2023-07-04 17:00:00','2023-08-07 17:00:00','30',NULL,'Watermelon is a fruit rich in water and essential vitamins and minerals, especially low in calories and fat. Watermelon is considered an alternative to regular drinking water.','<p>Watermelon is a fruit rich in water and essential vitamins and minerals, especially low in calories and fat. Watermelon is considered an alternative to regular drinking water. Sweet melon when the fruit is round, withered, dark green with a yellow tip.</p>',NULL,1,NULL,NULL,1,1,1,'2023-06-26 10:04:32','2023-07-11 06:24:11',NULL),(9,3,2,16,'11110','Set of 2 old South American bananas','set-of-2-old-south-american-bananas','upload/products/thumbnail/1770662009587809_product_thumbnail.jpg','189','new product','390','mililiter',NULL,'2023-07-05 17:00:00','2024-07-12 17:00:00','20','16','Old bananas are favored by many customers. Bananas contain many nutrients such as potassium, fiber, vitamins,... Bananas are best eaten when they are ripe, brown spots on the skin, then the bananas will be very sweet... Commitment to the right volume, packaging discreet, safe and hygienic.','<p>Old bananas are favored by many customers. Bananas contain many nutrients such as potassium, fiber, vitamins,... Bananas are best eaten when they are ripe, brown spots on the skin, then the bananas will be very sweet... Commitment to the right volume, packaging discreet, safe and hygienic.</p>',NULL,NULL,1,NULL,1,1,1,'2023-06-26 10:11:40','2023-07-11 06:24:11',NULL),(12,1,4,26,'22223','Pepsi Cola soft drink bottle 390ml','pepsi-cola-soft-drink-bottle-390ml','upload/products/thumbnail/1770858330207367_product_thumbnail.jpg','999','new product','390','mililiter',NULL,'2023-07-07 17:00:00','2023-09-20 17:00:00','10','2','From the global famous Pepsi soft drink brand with delicious taste with a mixture of natural flavors and synthetic sweeteners, helping to dispel thirst and fatigue. Pepsi Cola soft drink 390ml replenishes working energy every day. Committed to genuine, quality and safe soft drinks','<p>From the global famous Pepsi soft drink brand with delicious taste with a mixture of natural flavors and synthetic sweeteners, helping to dispel thirst and fatigue. Pepsi Cola soft drink 390ml replenishes working energy every day. Committed to genuine, quality and safe soft drinks</p>',NULL,NULL,1,NULL,1,1,NULL,'2023-07-08 13:15:07','2023-07-11 06:24:11',NULL),(13,3,4,24,'9995','Coca Cola soft drink 600ml bottle','coca-cola-soft-drink-600ml-bottle','upload/products/thumbnail/1770858742096612_product_thumbnail.jpg','999','new product','600','mililiter',NULL,'2023-06-27 17:00:00','2023-11-15 17:00:00','22','19','Expiry date  more than 3 months','<p>From the brand of soft drinks that are loved by many people with delicious and refreshing taste. Coca Cola soft drink 600ml genuine Coca Cola soft drink with a large amount of gas will help you dispel all feelings of fatigue, stress, bring a sense of comfort after outdoor activities</p>',NULL,NULL,NULL,1,1,1,NULL,'2023-07-08 13:21:40','2023-07-11 06:24:11',NULL),(14,3,4,25,'9994','Mirinda soft drink with sassafras 390ml bottle','mirinda-soft-drink-with-sassafras-390ml-bottle','upload/products/thumbnail/1770858981971577_product_thumbnail.jpg','999','new product','390','mililiter',NULL,'2023-06-28 17:00:00','2023-12-07 17:00:00','11','10','Expiry date  more than 3 months','<p>Soft drinks from the famous Mirinda soft drink brand are popular with many people with attractive flavor and taste. Mirinda sassafras soft drink 390ml bottle has a unique and natural sassafras flavor to help you quickly quench thirst, with a light gas taste, it is a great refreshment drink for all ages.</p>',NULL,NULL,NULL,1,1,1,NULL,'2023-07-08 13:25:29','2023-07-11 06:24:11',NULL),(15,4,7,9,'9990','4KFarm boiled duck eggs box of 4','4kfarm-boiled-duck-eggs-box-of-4','upload/products/thumbnail/1770859413687311_product_thumbnail.jpg','99','new product','8','gram',NULL,'2023-07-07 17:00:00','2023-07-14 17:00:00','15','11','Use during the week','<p>Box of 4 duck eggs 4KFarm is packed and preserved according to strict standards of hygiene and food safety, ensuring the quality of food. Duck eggs of 4K Farm are round and even. This product is suitable for cooking dishes such as fried eggs, duck egg porridge,...</p>',1,NULL,1,NULL,1,1,NULL,'2023-07-08 13:32:21','2023-07-11 06:24:11',NULL),(16,4,7,10,'7778','Fresh quail eggs 4KFarm box of 30 eggs','fresh-quail-eggs-4kfarm-box-of-30-eggs','upload/products/thumbnail/1770859849710828_product_thumbnail.jpg','99','new product','10','gram',NULL,'2023-07-07 17:00:00','2023-07-14 17:00:00','10',NULL,'Use during the week','<p>Boxes of 30 fresh 4KFarm quail eggs from 4KFarm egg brand are packed and preserved according to strict standards of hygiene and food safety, ensuring the quality of food. Quail eggs are round and even. Quail eggs can be boiled and processed into a number of dishes such as smoked quail eggs,...</p>',NULL,NULL,1,NULL,1,NULL,NULL,'2023-07-08 13:39:16','2023-07-11 06:24:11',NULL),(17,2,5,5,'99933','Pedigree Large Dog Food with Chicken Flavored with Sauce 130g','pedigree-large-dog-food-with-chicken-flavored-with-sauce-130g','upload/products/thumbnail/1770860067635831_product_thumbnail.jpg','99','new product','130','gram',NULL,'2023-07-07 17:00:00','2024-07-07 17:00:00','22','14','Used for more than 1 year','<p>Pedigree dog food contains many nutrients and vitamins to help strengthen the dog\'s immune system. Pedigree Large Dog Food with Chicken Flavor 130g is a dog food product with a paste form, you can feed it alone or mix it with your dog\'s current food.</p>',NULL,NULL,NULL,1,1,1,NULL,'2023-07-08 13:42:44','2023-07-11 06:24:11',NULL),(18,2,5,5,'99768','Natural Core dog food with chicken and salmon 2kg pack','natural-core-dog-food-with-chicken-and-salmon-2kg-pack','upload/products/thumbnail/1770860304760429_product_thumbnail.jpg','99','new product','2','kilogam',NULL,'2023-06-30 17:00:00','2023-09-08 17:00:00','20','10','Use more than 3 months','<p>Natural Core dog food is a famous Korean brand, specializing in dog food products, giving your pet a complete and delicious source of nutrients. Natural Core Chicken and Salmon Dog Food 2kg pack is a great choice for your pet.</p>\r\n<p>Boneless meat (hydrolyzed chicken, hydrolysed salmon, chicken meal) brown rice, sweet potatoes, potatoes, cold seeds, chicken fat, beet pulp, sugar, Yucca extract, fish oil, red ginseng, salt dried, taurinee, sea buckthorn, evening primrose seeds, carrots, coriander, spinach, vitamins and minerals.</p>',1,NULL,NULL,NULL,1,1,NULL,'2023-07-08 13:46:30','2023-07-11 06:24:11',NULL),(19,2,5,6,'2002','Minino tuna cat food 480g pack','minino-tuna-cat-food-480g-pack','upload/products/thumbnail/1770860661600586_product_thumbnail.jpg','55','new product','480','gram',NULL,'2023-07-07 17:00:00','2023-11-22 17:00:00','28',NULL,'Expiry date more than 4 months','<p>Product information<br>Cat food is an essential food source because of its convenience and completeness of nutrients. Minino tuna cat food 480g pack with delicious tuna flavor, bringing appetite for cats. Minino cat food is a brand trusted by many people.</p>',NULL,1,1,NULL,1,NULL,NULL,'2023-07-08 13:52:11','2023-07-11 06:24:11',NULL),(20,2,6,11,'2003','AFC Nutritional Vegetable Cracker 193.8g','afc-nutritional-vegetable-cracker-193.8g','upload/products/thumbnail/1770861349977899_product_thumbnail.jpg','99','new product','193.8','gram',NULL,'2023-07-07 17:00:00','2024-01-25 17:00:00','9','8','Expiry date more than 6 months','<p>AFC biscuits with added potatoes, provide energy, protein, fiber, especially vitamin D and calcium to help strengthen bones and at the same time strengthen the digestive system. AFC Nutritional Vegetable Cracker 193.8g is suitable as a nutritious snack cookie for busy people.</p>',1,NULL,1,NULL,1,1,NULL,'2023-07-08 14:03:07','2023-07-11 06:24:11',NULL),(21,2,6,12,'2004','Oreo Cookies Chocolate Cream Pack 119.6g','oreo-cookies-chocolate-cream-pack-119.6g','upload/products/thumbnail/1770861555027314_product_thumbnail.jpg','99','new product','119.6','gram',NULL,'2023-07-07 17:00:00','2023-12-13 17:00:00','4',NULL,'Expiry date is more than 5 months','<p><a href=\"https://www.bachhoaxanh.com/banh-quy\">B&aacute;nh quy</a>&nbsp;kẹp kem socola thơm ngon, với lớp vỏ m&agrave;u đen, c&oacute; vị đắng nhẹ nhưng lại ngọt kh&ocirc;ng gắt k&iacute;ch th&iacute;ch vị gi&aacute;c.&nbsp;<a href=\"https://www.bachhoaxanh.com/banh-quy/banh-oreo-vi-kem-chocola-137g\">B&aacute;nh quy Oreo kem socola g&oacute;i 119.6g</a>&nbsp;dinh dưỡng, ngon miệng, vừa ăn vừa chơi.&nbsp;<a href=\"https://www.bachhoaxanh.com/banh-quy-oreo\">B&aacute;nh quy&nbsp;Oreo</a>&nbsp;c&oacute; thể chấm sữa ăn rất th&uacute; vị hoặc l&agrave;m nguy&ecirc;n liệu l&agrave;m b&aacute;nh</p>',1,NULL,1,NULL,1,NULL,NULL,'2023-07-08 14:06:23','2023-07-11 06:24:11',NULL),(22,2,6,12,'2005','Malkist Crackers Roma Cake 140g','malkist-crackers-roma-cake-140g','upload/products/thumbnail/1770861736319173_product_thumbnail.jpg','99','new product','140','gram',NULL,'2023-07-07 17:00:00','2023-12-07 17:00:00','13','10','Expiry date is more than 5 months','<p>Fragrant, crunchy, milky milk biscuits with a thin layer of sugar on top of the cake. Malkist Roma Cookies 140g pack is packed into convenient small packages, easy to carry out, suitable for snacking or enjoying tea. Roma biscuits are made in Indonesia with quality, delicious.</p>',NULL,NULL,NULL,1,1,1,NULL,'2023-07-08 14:09:16','2023-07-11 06:24:11',NULL),(23,5,3,4,'2007','Squid tablets 5-star kitchen 200g','squid-tablets-5-star-kitchen-200g','upload/products/thumbnail/1770862037659165_product_thumbnail.jpg','99','new product','200','gram',NULL,'2023-06-24 17:00:00','2024-04-07 17:00:00','50','30','Expiry date is more than 10 months','<p>The 5 Star Kitchen Squid Ball is made from delicious fresh fish and squid, well seasoned. In addition, the 5-star kitchen ink pellets 500g package also meet food hygiene and safety standards. Therefore, when using, you will feel the full aroma and rich taste in each piece of crispy squid.<br>Ball balls, squid balls, ... are one of the favorite snacks of many people, especially young people. In order to meet and conquer user\'s taste, the 5 Star Kitchen food brand has launched the product 5 Star Kitchen Squid with 200g package to help the menu in your family become richer and more delicious.</p>',1,NULL,NULL,NULL,1,1,NULL,'2023-07-08 14:14:03','2023-07-11 06:24:11',NULL),(24,5,3,21,'2008','SG Food caviar individual fish balls 250g','sg-food-caviar-individual-fish-balls-250g','upload/products/thumbnail/1770862502028941_product_thumbnail.png','99','new product','250','gram',NULL,'2023-07-07 17:00:00','2024-02-07 17:00:00','12','8','Expiry date is more than 7 months','<p>SG Food brand fish ball with a unique recipe, the product ensures to keep the delicious taste of each fish ball. SG Food Caviar Fish Balls 250g box is made from fresh fish ingredients combined with unique caviar filling, easy to prepare fried dishes, sauces, hot pot,...</p>',1,NULL,NULL,NULL,1,1,NULL,'2023-07-08 14:21:26','2023-07-11 06:24:11',NULL),(25,5,3,3,'2009','Grilled Tuna 300g','grilled-tuna-300g','upload/products/thumbnail/1770862973179668_product_thumbnail.jpg','11','new product','300','gram',NULL,'2023-07-06 17:00:00','2023-07-08 17:00:00','9',NULL,'Use for 2 days','<p>Tuna is lean, low in fat, rich in nutrients and essential minerals for health, so many people choose it. Ready-made grilled tuna is convenient, easy to use, delicious taste, suitable for the whole family<br>Advantages of buying grilled tuna at NestShop<br>Delicious grilled tuna, quality, chewy, sweet meat. Tuna is pre-baked, packed in 300g trays, vacuum sealed for easier storage.<br>Tuna is guaranteed of clear origin.<br>Order fast delivery</p>',NULL,NULL,1,1,1,1,NULL,'2023-07-08 14:28:55','2023-07-11 06:24:11',NULL),(26,4,1,13,'2010','Broccoli 300g (1 flower)','broccoli-300g-(1-flower)','upload/products/thumbnail/1770863241100374_product_thumbnail.jpg','999','new product','300','gram',NULL,'2023-07-07 17:00:00','2023-07-14 17:00:00','22','20','Use during the week','<p>Broccoli is a familiar green vegetable and is loved by many people. Broccoli grown in China is not only delicious, easy to eat, but also brings a lot of health benefits. Broccoli can be processed into steamed broccoli, saut&eacute;ed broccoli, broccoli soup, ...<br>Advantages of buying broccoli at Bach Hoa Xanh<br>Broccoli is fresh, delicious, and is a popular vegetable. Broccoli has small green flowers that grow tightly together, surrounded by a protective layer of hard leaves. Broccoli is sweet, crispy and nutritious.<br>Broccoli is guaranteed to have a clear origin, selling in a 300g bag of about 1 flower.<br>Order fast delivery</p>',NULL,1,NULL,NULL,1,1,NULL,'2023-07-08 14:33:11','2023-07-11 06:24:11',NULL),(27,4,1,13,'2011','Broccol white ready-made tray 300g','broccol-white-ready-made-tray-300g','upload/products/thumbnail/1770863699172020_product_thumbnail.jpg','96','new product','300','gram',NULL,'2023-07-07 17:00:00','2023-07-14 17:00:00','16','15','Use during the week','<p>Cabbage ready-made tray 300g includes: Broccoli,... This is an extremely healthy vegetable, containing many important nutrients. Products are fresh, quality, ensure food safety, are packed in a clean pre-processing tray. Very suitable for busy families with no time, convenience.</p>',NULL,1,NULL,NULL,1,1,NULL,'2023-07-08 14:40:28','2023-07-12 03:19:26',NULL),(28,4,1,14,'9998','Spinach 300g','spinach-300g','upload/products/thumbnail/1770864052219367_product_thumbnail.jpg','96','new product','300','gram',NULL,'2023-07-09 17:00:00','2023-07-10 17:00:00','3','2','Use for 3 days','<p>Với c&ocirc;ng dụng tuyệt vời, rau cải b&oacute; x&ocirc;i c&oacute; thể chống ung thư, chống vi&ecirc;m, ngăn ngừa bệnh tuyến tiền liệt, hỗ trợ giảm c&acirc;n, l&agrave;m đẹp da, s&aacute;ng mắt,.... Cải b&oacute; x&ocirc;i của B&aacute;ch h&oacute;a xanh được trồng tại Đ&agrave; Lạt tự tin mang đến cho bạn những m&oacute;n ăn đầy đủ dinh dưỡng, hấp dẫn v&agrave; thanh m&aacute;t.<br>Ưu điểm khi mua cải b&oacute; x&ocirc;i tại NestShop</p>\r\n<p>Rau cải b&oacute; x&ocirc;i tươi ngon, chất lượng, được đ&oacute;ng trong t&uacute;i kh&iacute; gi&uacute;p bảo quản rau tốt hơn khi vận chuyển, kh&ocirc;ng bị dập, hư rau.<br>Rau cải được đảm bảo nguồn gốc xuất xứ r&otilde; r&agrave;ng, đ&oacute;ng g&oacute;i 300g.<br>Đặt giao h&agrave;ng nhanh</p>',NULL,NULL,NULL,1,1,1,NULL,'2023-07-08 14:46:04','2023-07-12 03:19:26',NULL),(29,4,2,8,'33344','Strawberry 1kg','strawberry-1kg','upload/products/thumbnail/1770869004372000_product_thumbnail.jpg','97','new product','1','kilogam',NULL,'2023-07-07 17:00:00','2023-07-14 17:00:00','45','32','Use during the week','<p>Strawberry (scientific name: Fragaria &times; ananassa) is a genus of angiosperms and flowering plants in the Rose family (Rosaceae). Strawberries originated in the Americas and were bred by European gardeners in the 18th century to create the variety of strawberry that is widely grown today. This shoulder was first scientifically described by (Weston) Duchesne in 1788. This fruit is appreciated by many people for its characteristic aroma, bright red color, succulent and sweet taste. It is consumed in large quantities, either consumed as fresh berries or made into jams, juices, pies, ice cream, lotions and chocolates. Artificial strawberry flavorings and ingredients are also widely used in products such as candy, soap, lip gloss, perfume, and many others.</p>',NULL,NULL,1,NULL,1,1,1,'2023-07-08 14:51:48','2023-07-12 03:19:26',NULL),(30,4,2,7,'99912','Ninh Thuan red grapes 500g','ninh-thuan-red-grapes-500g','upload/products/thumbnail/1770864602731225_product_thumbnail.jpg','97','new product','500','gram',NULL,'2023-07-07 17:00:00','2023-07-14 17:00:00','25','15','Use during the week','<p>Product information<br>Red grapes have thick succulent flesh, sweet and sour taste in harmony, is a fruit that many people love on summer days. Ninh Thuan red grapes bring many health benefits, sweet grapes when they have purple-red, dark, evenly ripened, firm, berry skins.</p>',1,NULL,NULL,NULL,1,1,NULL,'2023-07-08 14:54:49','2023-07-12 03:19:26',NULL),(31,1,4,27,'77645','C2 Green Tea Lemon Flavor 360ml','c2-green-tea-lemon-flavor-360ml','upload/products/thumbnail/1770866620467374_product_thumbnail.jpg','38','new product','360','gram',NULL,'2023-07-07 17:00:00','2024-03-07 17:00:00','8',NULL,'Expiry date more than 8 months','<p>Extracted from natural green tea leaves from the highlands of Vietnam, blended with fresh lemon flavor, it gives you a great refreshing drink on hot days. Green tea contains high levels of antioxidants, which help you stay active and excited.<br>C2 is a brand of bottled tea very familiar to Vietnamese consumers, C2 Tea is distilled from 100% natural green tea in the highlands of Vietnam, processed and bottled on the same day according to international standards, helping ensure the freshness and purity of the tea. C2 tea has many delicious flavors and affordable price, is the first choice of consumers.</p>\r\n<p>C2 Green Tea Lemon Flavor 360ml is a bottled tea product from C2 tea brand. Extracted from natural green tea leaves from the highlands of Vietnam, blended with fresh lemon flavor, it gives you a great refreshing drink on hot days. Green tea contains high levels of antioxidants, which help you stay active and excited.</p>',NULL,1,1,NULL,1,1,NULL,'2023-07-08 15:26:54','2023-07-12 03:19:26',NULL),(32,4,2,7,'73432','American seedless black grapes 1kg','american-seedless-black-grapes-1kg','upload/products/thumbnail/1770868933243138_product_thumbnail.jpg','22','new product','1','kilogam',NULL,'2023-07-07 17:00:00','2023-07-14 17:00:00','30','22','Use during the week','<p>Information<br>American seedless black currants are native to California, Oregon, and Washington, where the climate is warm and dry. With a variety of strains: Autumn royal, Midnight Beauty, Sugrathirteen, Summer Roya and Autumn royal are the tastier ones.</p>\r\n<p>American seedless black grapes have conquered and enjoyed worldwide popularity. In Vietnam, at imported fruit stores you will easily see it from May to January next year.<br>Characteristic</p>\r\n<p>Seedless black grapes are oblong, dark black, thin skinned. Eat very sweet but still have a cool taste, especially without seeds</p>\r\n<p>The characteristics are also a way for consumers to know how to distinguish from China\'s toxic grape products.</p>\r\n<p>3. Nutrition and health</p>\r\n<p>Black currant is a fruit that is very nutritious, has the effect of tonic, useful gas, helps the body healthy, good immunity and slows down the aging process.</p>\r\n<p>- Calcium, potassium, phosphorus, iron, vitamins B1, B2, B6, C and essential amino acids are good for people with neurasthenia and beneficial for digestion.</p>\r\n<p>- Resveratrol compound in American meatless black currant, especially the skin, helps detoxify well, reduce fatty blood, fight blood clots, prevent atherosclerosis and strengthen the body\'s immune system.</p>',1,NULL,NULL,NULL,1,1,1,'2023-07-08 16:03:39','2023-07-11 06:24:11',NULL),(33,1,4,26,'2705','Pepsi Cola soft drink can 320ml','pepsi-cola-soft-drink-can-320ml','upload/products/thumbnail/1770869250027177_product_thumbnail.jpg','99','new product','320','mililiter',NULL,'2023-07-07 17:00:00','2024-04-07 17:00:00','3',NULL,'Expiry date  more than 11 months','<p>Product information<br>Products from the global famous Pepsi soft drink brand with delicious taste with a mixture of natural flavors and synthetic sweeteners, help dispel thirst and fatigue. Pepsi Cola soft drink 320ml can replenish working energy every day. Committed to genuine, quality and safe soft drinks<br>About Pepsi brand<br>Pepsi is a global famous beverage giant, the world\'s leading soft drink brand that almost everyone knows, this brand has a history of establishment since 1893 in North Carolina, USA.</p>\r\n<p>Pepsi is a globally famous brand of carbonated Cola-flavored beverage, which inherits many long-standing historical values. In Vietnam, proud to be a brand that represents the voice of young people with the message \"Stay young, keep quality, keep PEPSI\", we always seek to bring the ultimate refreshing experiences, encouraging encourage young people to capture and enjoy every exciting moment of life.</p>\r\n<p>Soft drinks with Gaz Pepsi with attractive cola flavor, bring refreshing feeling, instant cooling in hot days. Served directly, it tastes better when chilled, or served with ice.</p>\r\n<p>Pepsi officially entered the Vietnamese beverage market in 1994 and received the favorite wave of users, especially young people. Currently, Pepsi has many product lines with flavors suitable for many customers such as Pepsi Cola, Pepsi Light, Pepsi no calories, ...</p>',1,NULL,NULL,NULL,1,1,1,'2023-07-08 16:08:41','2023-07-10 02:51:20',NULL),(34,5,3,3,'77947','Dongwon Vegetable Tuna 150g','dongwon-vegetable-tuna-150g','upload/products/thumbnail/1770869571660050_product_thumbnail.jpg','99','new product','150','gram',NULL,'2023-07-07 17:00:00','2024-05-07 17:00:00','10','9','Expiry date is more than 10 months','<p>Product information<br>Dongwon vegetable tuna canned 150g from Korea is a great combination of fresh vegetables with fatty tuna, the sweetness of tuna mixed with soft cooked vegetables to create a delicious dish. Tasty, delicious and full of nutrition.<br>Dongwon canned fish brand from Korea brings you Dongwon vegetable tuna canned 150g. This is a delicious and convenient canned fish combined with vegetables.</p>\r\n<p>Natural ingredients<br>Products are made with natural ingredients such as tuna, cabbage, potatoes, carrots, sweet corn, peas, red chili sauce, tomato sauce... safe for your family\'s health.<br>The snap-on tin can make it easier to use. The 150g small box is more convenient and economical, suitable for meals from 2-3 people.</p>',NULL,NULL,1,NULL,1,1,1,'2023-07-08 16:13:48','2023-07-10 02:51:15',NULL),(40,4,1,14,'171718','Onion 300g (2 - 3 bulbs)','onion-300g-(2---3-bulbs)','upload/products/thumbnail/1771000266668586_product_thumbnail.jpg','70','new product','300','gram',NULL,'2023-07-10 17:00:00','2023-07-11 17:00:00','30','26','Onion originating in China is a common root used in many Vietnamese and worldwide dishes. This vegetable contains quite a lot of vitamins and minerals that are beneficial for health. Onions can be fried, sautéed, grilled or eaten raw.','<p>Onions are tubers that grow underground, are grown worldwide, and are closely related to chives, garlic, and green onions. This is a key ingredient in many dishes, processed in a variety of ways, from baking, boiling, frying, roasting, stir-frying, rolling dough or even eating raw. Onions contain a lot of vitamins and minerals with health benefits such as: helping to regulate blood sugar, improve bone health, prevent cancer, strengthen the immune system, ...</p>\r\n<p>How to prepare onions<br>- Wash the onion with water.<br>- Use a peeler knife.<br>- Cut areca, circle, small sharp depending on the dish you prepare.<br>- To reduce the pungent taste, soak in a bowl of water mixed with a little lemon or vinegar for 15 minutes.<br>To make the onions crispy, soak the onions in cold water for 30 minutes.<br>Reference: Ways to cut onions without worrying about burning eyes.<br>Dishes made with onions<br>- Stir-fried chicken with onions in a strange mouth, bring rice.<br>- Crispy with fried squid with onion.<br>- Stir-fried beef with onions, soft and delicious.<br>- French onion soup.<br>In addition to being used as a dish, onions are also used to clean the house, clean the grill, remove all stains on the white shirt, ...<br>Note: The product received may be different from the picture in color and quantity, but it is still guaranteed in terms of volume and quality.</p>',1,NULL,NULL,NULL,1,1,NULL,'2023-07-10 02:51:09','2023-07-11 12:37:32',NULL),(41,1,4,27,'1qa2ws','Box of 24 bottles of C2 peach red tea 455ml','box-of-24-bottles-of-c2-peach-red-tea-455ml','upload/products/thumbnail/1771182415866662_product_thumbnail.jpg','90','new product','455','mililiter',NULL,'2023-07-11 17:00:00','2025-07-11 17:00:00','20',NULL,'C2 tea is distilled from 100% natural tea, processed and bottled in the same day, providing a great tea flavor. The box of 24 bottles of C2 peach red tea 455ml gives you a new choice in enjoying tea, helping to quench thirst, replenishing energy for a long, active and refreshing day.','<p>About the C2 . brand<br>C2 is a brand of bottled tea very familiar to Vietnamese consumers, C2 Tea is distilled from 100% natural green tea in the highlands of Vietnam, processed and bottled on the same day according to international standards, helping ensure the freshness and purity of the tea. C2 tea has many delicious flavors and affordable price, is the first choice of consumers.</p>\r\n<p>Box of 24 bottles of C2 peach red tea 455ml 0<br>Nutritional composition of C2 peach red tea 455ml<br>The product is made from naturally fermented tea leaves with a strong tea flavor mixed with the light, sweet taste of peaches.</p>\r\n<p>Ingredients contain protein, fat, protein, vitamin B, vitamin C, vitamin B1, and many minerals necessary for the body.</p>\r\n<p>The product\'s energy level is about 47 calories/100ml</p>\r\n<p>Uses of the product for health<br>Delicious beverage</p>\r\n<p>Fresh flavors for active days</p>\r\n<p>Rich in antioxidants to help beautify the skin, prevent aging,...</p>\r\n<p><br>How to store and note about products<br>To a dry, cool place</p>\r\n<p>Avoid exposure to direct sunlight</p>\r\n<p>Tastes better when cold, shake well before drinking</p>\r\n<p>Do not drink close to bedtime at night</p>\r\n<p>Do not use expired products with strange odors</p>',1,NULL,NULL,NULL,1,NULL,NULL,'2023-07-12 03:06:19','2023-07-12 03:10:25',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `received_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `received_mails` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `received_mails` WRITE;
/*!40000 ALTER TABLE `received_mails` DISABLE KEYS */;
INSERT INTO `received_mails` VALUES (2,'laiminhkiet07052002@gmail.com','I need help with how to make purchases on your website.I need help with how to make purchases on your website.I need help with how to make purchases on your website.','I need help with how to make purchases on your website.I need help with how to make purchases on your website.I need help with how to make purchases on your website.I need help with how to make purchases on your website.',1,0,'2023-07-03 10:07:10','2023-07-11 15:26:39');
/*!40000 ALTER TABLE `received_mails` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_product_id_foreign` (`product_id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (15,34,18,'Good quality product!','5','1','2023-07-11 14:45:46','2023-07-11 14:46:33');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(1,2),(2,1),(2,2),(3,1),(3,2),(4,1),(4,2),(5,1),(5,2),(6,1),(6,2),(7,1),(7,2),(8,1),(8,2),(9,1),(9,2),(10,1),(10,2),(11,1),(11,2),(12,1),(12,2),(13,1),(13,2),(14,1),(14,2),(15,1),(15,2),(16,1),(16,2),(17,1),(17,2),(18,1),(18,2),(19,1),(19,2),(20,1),(20,2),(21,1),(21,2),(22,1),(22,2),(23,1),(23,2),(24,1),(24,2),(25,1),(25,2),(26,1),(26,2),(27,1),(27,2),(28,1),(28,2),(29,1),(29,2),(30,1),(30,2),(31,1),(31,2),(32,1),(32,2),(33,1),(33,2),(34,1),(34,2),(35,1),(35,2),(36,1),(36,2),(37,1),(37,2),(38,1),(38,2),(39,1),(39,2),(40,1),(40,2),(41,1),(41,2),(42,1),(42,2),(43,1),(43,2),(44,1),(44,2),(45,1),(45,2),(46,1),(46,2),(47,1),(47,2),(48,1),(49,1),(50,1),(50,2),(51,1),(51,2),(52,1),(52,2),(53,1),(53,2),(54,1),(54,2),(55,1),(55,2),(56,1),(56,2),(57,1),(57,2),(58,1),(58,2),(59,1),(59,2),(60,1),(60,2),(61,1),(61,2),(62,1),(62,2),(63,1),(63,2),(64,1),(64,2),(65,1),(65,2),(66,1),(66,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'SuperAdmin','web','2023-06-26 02:29:19','2023-06-26 02:29:19'),(2,'Admin','web','2023-06-26 02:29:23','2023-06-26 02:29:23');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `seos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keyword` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `seos` WRITE;
/*!40000 ALTER TABLE `seos` DISABLE KEYS */;
INSERT INTO `seos` VALUES (1,'Nest','Nest','Nest','Nest Shop','2023-06-25 04:39:43','2023-07-01 15:19:47');
/*!40000 ALTER TABLE `seos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ship_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ship_cities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `city_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ship_cities` WRITE;
/*!40000 ALTER TABLE `ship_cities` DISABLE KEYS */;
INSERT INTO `ship_cities` VALUES (1,'Ho Chi Minh city','2023-06-25 04:29:08',NULL),(2,'Ha Noi city','2023-06-25 04:29:12',NULL),(3,'Da Nang city','2023-06-25 04:29:16',NULL),(8,'Hai Phong city','2023-07-08 04:23:57',NULL),(9,'Can Tho city','2023-07-08 04:26:13',NULL),(10,'An Giang province','2023-07-08 04:26:36',NULL),(11,'Bac Giang province','2023-07-08 04:27:16',NULL),(12,'Bac Kan province','2023-07-08 04:27:29','2023-07-08 04:27:54'),(13,'Bac Lieu province','2023-07-08 04:28:11',NULL),(14,'Bac Ninh province','2023-07-08 04:28:21',NULL),(15,'Ben Tre province','2023-07-08 04:28:53',NULL),(16,'Binh Dinh province','2023-07-08 04:29:16',NULL),(17,'Binh Duong province','2023-07-08 04:29:31',NULL),(18,'Binh Phuoc province','2023-07-08 04:29:51',NULL),(19,'Binh Thuan province','2023-07-08 04:30:07',NULL),(20,'Ca Mau province','2023-07-08 04:30:40',NULL),(21,'Can Tho province','2023-07-08 04:30:59',NULL),(22,'Cao Bang province','2023-07-08 04:31:11',NULL),(23,'Dak Lak','2023-07-08 04:31:43','2023-07-08 04:34:35'),(24,'Dak Nong','2023-07-08 04:31:59','2023-07-08 04:34:23'),(25,'Dien Bien province','2023-07-08 04:32:36',NULL),(26,'Dong Nai province','2023-07-08 04:32:49',NULL),(27,'Dong Thap province','2023-07-08 04:33:00',NULL),(28,'Gia Lai province','2023-07-08 04:33:25',NULL),(29,'Ha Giang province','2023-07-08 04:33:41',NULL),(30,'Ha Nam province','2023-07-08 04:33:56',NULL),(31,'Ha Tinh province','2023-07-08 04:34:07',NULL),(32,'Hai Duong province','2023-07-08 04:34:56',NULL),(33,'Hau Giang province','2023-07-08 04:35:33',NULL),(34,'Hoa Binh province','2023-07-08 04:35:42',NULL),(35,'Hung Yen province','2023-07-08 04:35:55',NULL),(36,'Khanh Hoa province','2023-07-08 04:36:04',NULL),(37,'Kien Giang province','2023-07-08 04:36:37',NULL),(38,'Kom Tum province','2023-07-08 04:36:45',NULL),(39,'Lai Chau province','2023-07-08 04:37:06',NULL),(40,'Lam Dong province','2023-07-08 04:37:18',NULL),(41,'Lang Son province','2023-07-08 04:37:27',NULL),(42,'Lao Cai province','2023-07-08 04:37:43',NULL),(43,'Long An province','2023-07-08 04:37:57',NULL),(44,'Nam Dinh province','2023-07-08 04:38:07',NULL),(45,'Nghe An province','2023-07-08 04:38:27',NULL),(46,'Ninh Binh province','2023-07-08 04:38:38',NULL),(47,'Ninh Thuan province','2023-07-08 04:38:46',NULL),(48,'Phu Tho province','2023-07-08 04:39:02',NULL),(49,'Phu Yen province','2023-07-08 04:39:09',NULL),(50,'Quang Binh province','2023-07-08 04:39:18',NULL),(51,'Quang Nam province','2023-07-08 04:39:27','2023-07-08 04:39:38'),(52,'Quang Ngai province','2023-07-08 04:39:56','2023-07-08 04:40:06'),(53,'Quang Ninh province','2023-07-08 04:40:17','2023-07-08 04:40:25'),(54,'Quang Tri province','2023-07-08 04:40:36',NULL),(55,'Soc Trang province','2023-07-08 04:40:53',NULL),(56,'Son La province','2023-07-08 04:41:03',NULL),(57,'Tay Ninh province','2023-07-08 04:41:17',NULL),(58,'Thai Binh province','2023-07-08 04:41:27',NULL),(59,'Thai Nguyen province','2023-07-08 04:41:38',NULL),(60,'Thanh Hoa province','2023-07-08 04:41:53',NULL),(61,'Thua Thien Hue province','2023-07-08 04:42:05',NULL),(62,'Tien Giang province','2023-07-08 04:42:26',NULL),(63,'Tra Vinh province','2023-07-08 04:42:44',NULL),(64,'Tuyen Quang province','2023-07-08 04:42:58',NULL),(65,'Vinh Long province','2023-07-08 04:43:16',NULL),(66,'Vinh Phuc province','2023-07-08 04:43:27',NULL),(67,'Yen Bai province','2023-07-08 04:43:36',NULL);
/*!40000 ALTER TABLE `ship_cities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ship_communes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ship_communes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `city_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `commune_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=302 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ship_communes` WRITE;
/*!40000 ALTER TABLE `ship_communes` DISABLE KEYS */;
INSERT INTO `ship_communes` VALUES (1,1,13,'An Phu Tay commune','2023-06-25 04:31:43',NULL),(2,1,13,'Tan Quy Tay commune','2023-06-25 04:31:52',NULL),(3,1,13,'Da Phuoc commue','2023-06-25 04:32:00',NULL),(4,1,13,'Vinh Loc B commune','2023-06-25 04:32:06',NULL),(5,1,13,'Vinh Loc A commune','2023-06-25 04:32:11',NULL),(6,1,13,'Le Minh Xuan commune','2023-06-25 04:32:27',NULL),(7,1,13,'Hung Long commnue','2023-06-25 04:32:39',NULL),(8,1,13,'Quy Duc commune','2023-06-25 04:32:50',NULL),(9,1,13,'Binh Chanh commune','2023-06-25 04:33:03',NULL),(19,1,13,'Tan Tuc commune','2023-07-08 01:51:06',NULL),(20,1,13,'Pham Van Hai commune','2023-07-08 01:52:06',NULL),(21,1,13,'Le Minh Xuan commune','2023-07-08 01:52:39',NULL),(22,1,13,'Phong Phu commune','2023-07-08 01:52:53',NULL),(23,1,13,'Tan Kien commune','2023-07-08 01:53:19',NULL),(24,1,13,'Tan Nhut commune','2023-07-08 01:53:42',NULL),(25,1,1,'Ben Nghe ward','2023-07-08 01:54:29',NULL),(26,1,1,'Ben Thanh ward','2023-07-08 01:54:44',NULL),(27,1,1,'Co Giang ward','2023-07-08 01:55:15',NULL),(28,1,1,'Nguyen Cu Trinh ward','2023-07-08 01:55:34',NULL),(29,1,1,'Pham Ngu Lao ward','2023-07-08 01:55:59','2023-07-08 02:01:23'),(30,1,1,'Nguyen Thai Binh ward','2023-07-08 01:56:38',NULL),(31,1,1,'Da Kao ward','2023-07-08 01:56:52',NULL),(32,1,1,'Cau Ong Lanh ward','2023-07-08 02:00:46',NULL),(33,1,1,'Cau Kho ward','2023-07-08 02:01:15',NULL),(34,1,26,'Tan Hiep commune','2023-07-08 02:04:37',NULL),(35,1,26,'Tan Xuan commune','2023-07-08 02:05:01',NULL),(36,1,26,'Trung Chanh commune','2023-07-08 02:05:44',NULL),(37,1,26,'Ba Diem commune','2023-07-08 02:06:44',NULL),(38,1,26,'Nhi Binh commune','2023-07-08 02:07:03',NULL),(39,1,26,'Xuan Thoi Dong commune','2023-07-08 02:07:46',NULL),(40,1,26,'Xuan Thoi Thuong commune','2023-07-08 02:08:20',NULL),(41,1,26,'Xuan Thoi Son commune','2023-07-08 02:08:40',NULL),(42,1,26,'Thoi Tam Thon commune','2023-07-08 02:09:04',NULL),(43,1,25,'Binh Khanh commune','2023-07-08 02:09:58',NULL),(44,1,25,'Long Hoa commune','2023-07-08 02:10:16',NULL),(45,1,25,'An Thoi Dong commune','2023-07-08 02:10:34',NULL),(46,1,25,'Tam Thon Hiep commune','2023-07-08 02:11:02',NULL),(47,1,25,'Ly Nhon commune','2023-07-08 02:11:25',NULL),(48,1,23,'An Phu commune','2023-07-08 02:12:16',NULL),(49,1,23,'Hoa Phu commune','2023-07-08 02:12:33',NULL),(50,1,23,'Phu My Hung commune','2023-07-08 02:12:55',NULL),(51,1,23,'Binh My commune','2023-07-08 02:13:08',NULL),(52,1,23,'Phuoc Hiep commune','2023-07-08 02:13:39',NULL),(53,1,23,'Trung An commune','2023-07-08 02:13:57',NULL),(54,1,23,'Tan Thanh Dong commune','2023-07-08 02:14:37',NULL),(55,1,23,'Tan An Hoi commune','2023-07-08 02:15:02',NULL),(56,1,23,'Tan Thong Hoi commune','2023-07-08 02:15:29',NULL),(57,1,23,'Thai My commune','2023-07-08 02:16:06',NULL),(58,1,23,'Trung Lap Ha commune','2023-07-08 02:16:26','2023-07-08 03:47:31'),(59,1,23,'Tan Thanh Tay commune','2023-07-08 02:17:09',NULL),(60,1,23,'Phu Hoa Dong commune','2023-07-08 02:19:21',NULL),(61,1,23,'Nhuan Duc commune','2023-07-08 02:19:40',NULL),(62,1,24,'Hiep Tan ward','2023-07-08 02:20:42',NULL),(63,1,24,'Phu Thanh ward','2023-07-08 02:20:58',NULL),(64,1,24,'Phu Trung ward','2023-07-08 02:21:21',NULL),(65,1,24,'Tan Quy ward','2023-07-08 02:21:34',NULL),(66,1,24,'Tan Thanh ward','2023-07-08 02:21:58',NULL),(67,1,24,'Tay Thanh ward','2023-07-08 02:22:14',NULL),(68,1,24,'Tan Son Nhi ward','2023-07-08 02:22:40',NULL),(69,1,24,'Tan Thoi Hoa ward','2023-07-08 02:23:03',NULL),(70,1,28,'Ward 1','2023-07-08 02:24:26','2023-07-08 02:25:05'),(71,1,28,'Ward 2','2023-07-08 02:25:18',NULL),(72,1,28,'Ward 3','2023-07-08 02:25:39',NULL),(73,1,28,'Ward 4','2023-07-08 02:25:56',NULL),(74,1,28,'Ward 5','2023-07-08 02:26:09',NULL),(75,1,28,'Ward 7','2023-07-08 02:26:25',NULL),(76,1,28,'Ward 8','2023-07-08 02:26:41',NULL),(77,1,28,'Ward 9','2023-07-08 02:27:16',NULL),(78,1,28,'Ward 10','2023-07-08 02:27:31','2023-07-08 02:28:18'),(79,1,28,'Ward  11','2023-07-08 02:27:45',NULL),(80,1,28,'Ward 12','2023-07-08 02:28:09',NULL),(81,1,28,'Ward 13','2023-07-08 02:28:31',NULL),(82,1,28,'Ward 14','2023-07-08 02:28:45',NULL),(83,1,28,'Ward 15','2023-07-08 02:29:00',NULL),(84,1,28,'Ward 17','2023-07-08 02:29:16',NULL),(85,1,29,'Ward 1','2023-07-08 02:30:43',NULL),(86,1,29,'Ward 2','2023-07-08 02:30:59',NULL),(87,1,29,'Ward 3','2023-07-08 02:32:54',NULL),(88,1,29,'Ward 5','2023-07-08 02:33:11','2023-07-08 02:35:11'),(89,1,29,'Ward 6','2023-07-08 02:35:23',NULL),(90,1,29,'Ward 7','2023-07-08 02:35:42','2023-07-08 02:35:51'),(91,1,29,'Ward 11','2023-07-08 02:36:04','2023-07-08 02:36:17'),(92,1,29,'Ward 12','2023-07-08 02:36:31',NULL),(93,1,29,'Ward 13','2023-07-08 02:36:44',NULL),(94,1,29,'Ward 14','2023-07-08 02:36:56',NULL),(95,1,20,'An Lac ward','2023-07-08 02:38:26',NULL),(96,1,20,'An Lac A ward','2023-07-08 02:38:58',NULL),(97,1,20,'Binh Hung Hoa ward','2023-07-08 02:39:22',NULL),(98,1,20,'Binh Hung Hoa A ward','2023-07-08 02:39:45',NULL),(99,1,20,'Binh Hung Hoa B ward','2023-07-08 02:40:01',NULL),(100,1,20,'Binh Tri Dong ward','2023-07-08 02:40:35',NULL),(101,1,20,'Binh Tri Dong A ward','2023-07-08 02:40:57',NULL),(102,1,20,'Binh Tri Dong B ward','2023-07-08 02:41:20',NULL),(103,1,20,'Tan Tao ward','2023-07-08 02:41:44',NULL),(104,1,20,'Tan Tao A ward','2023-07-08 02:42:20',NULL),(105,1,22,'Ward 1','2023-07-08 02:42:57',NULL),(106,1,22,'Ward 3','2023-07-08 02:43:09',NULL),(107,1,22,'Ward 4','2023-07-08 02:43:28',NULL),(108,1,22,'Ward 5','2023-07-08 02:43:50',NULL),(109,1,22,'Ward 6','2023-07-08 02:44:09',NULL),(110,1,22,'Ward 7','2023-07-08 02:44:26',NULL),(111,1,22,'Ward  8','2023-07-08 02:44:41',NULL),(112,1,22,'Ward  9','2023-07-08 02:44:56',NULL),(113,1,22,'Ward  10','2023-07-08 02:45:28',NULL),(114,1,22,'Ward  11','2023-07-08 02:45:57',NULL),(115,1,22,'Ward 12','2023-07-08 02:46:55',NULL),(116,1,22,'Ward 13','2023-07-08 02:47:11',NULL),(117,1,22,'Ward  14','2023-07-08 02:47:25',NULL),(118,1,21,'Ward  1','2023-07-08 02:49:48',NULL),(119,1,21,'Ward  2','2023-07-08 02:50:07',NULL),(120,1,21,'Ward  3','2023-07-08 02:50:30',NULL),(121,1,21,'Ward 4','2023-07-08 02:50:48',NULL),(122,1,21,'Ward 5','2023-07-08 02:51:02',NULL),(123,1,21,'Ward 6','2023-07-08 02:51:23','2023-07-08 02:51:30'),(124,1,21,'Ward 7','2023-07-08 02:51:45',NULL),(125,1,27,'Long Thoi commune','2023-07-08 02:53:11',NULL),(126,1,27,'Phu Xuan commune','2023-07-08 02:53:44',NULL),(127,1,27,'Phuoc Long commune','2023-07-08 02:54:03',NULL),(128,1,27,'Nhon Duc commune','2023-07-08 02:54:29',NULL),(129,1,27,'Hiep Phuoc commune','2023-07-08 02:54:48',NULL),(130,1,27,'Phuoc Kien commune','2023-07-08 02:55:04',NULL),(131,1,2,'An Khanh commune','2023-07-08 02:55:58',NULL),(132,1,2,'An Phu commune','2023-07-08 02:56:32',NULL),(133,1,2,'Binh Tho commune','2023-07-08 02:56:51',NULL),(134,1,2,'Binh Trung Tay commune','2023-07-08 02:57:15','2023-07-08 03:17:10'),(135,1,2,'Hiep Binh Chanh commune','2023-07-08 02:58:31',NULL),(136,1,2,'Hiep Phu commune','2023-07-08 02:58:49',NULL),(137,1,2,'Linh Dong commune','2023-07-08 02:59:16',NULL),(138,1,2,'Linh Trung commune','2023-07-08 02:59:35',NULL),(139,1,2,'Long Thanh My commune','2023-07-08 03:00:51',NULL),(140,1,2,'Phu Huu commune','2023-07-08 03:01:24','2023-07-08 03:01:39'),(141,1,2,'Linh Chieu commune','2023-07-08 03:02:49',NULL),(142,1,2,'Linh Xuan commune','2023-07-08 03:03:43',NULL),(143,1,2,'Linh Tay commune','2023-07-08 03:09:19',NULL),(144,1,2,'Long Phuoc commune','2023-07-08 03:09:39',NULL),(145,1,2,'Long Truong commune','2023-07-08 03:09:53',NULL),(146,1,2,'Hiep Binh Phuoc commune','2023-07-08 03:10:35',NULL),(147,1,2,'Phuoc Binh commune','2023-07-08 03:10:53',NULL),(148,1,2,'Phuoc Long A commune','2023-07-08 03:11:37',NULL),(149,1,2,'Phuoc Long B commune','2023-07-08 03:11:54',NULL),(150,1,2,'Thu Thiem commune','2023-07-08 03:12:35',NULL),(151,1,2,'Truong Tho commune','2023-07-08 03:12:51',NULL),(152,1,2,'Tam Phu commune','2023-07-08 03:13:07',NULL),(153,1,2,'Tam Binh commune','2023-07-08 03:14:00',NULL),(154,1,2,'Tan Phu commune','2023-07-08 03:14:14',NULL),(155,1,2,'Thao Dien commune','2023-07-08 03:14:40',NULL),(156,1,2,'Truong Thanh commune','2023-07-08 03:14:56',NULL),(157,1,2,'Tang Nhon Phu A commune','2023-07-08 03:15:25','2023-07-08 03:15:58'),(158,1,2,'Tang Nhon Phu B commune','2023-07-08 03:15:48',NULL),(159,1,2,'Thanh My Loi commune','2023-07-08 03:16:32',NULL),(160,1,21,'Ward  8','2023-07-08 03:18:06',NULL),(161,1,21,'Ward  9','2023-07-08 03:18:23',NULL),(162,1,21,'Ward  10','2023-07-08 03:18:39',NULL),(163,1,21,'Ward  11','2023-07-08 03:18:54',NULL),(164,1,21,'Ward  12','2023-07-08 03:19:34',NULL),(165,1,21,'Ward  13','2023-07-08 03:19:45',NULL),(166,1,21,'Ward  14','2023-07-08 03:19:57',NULL),(167,1,21,'Ward  15','2023-07-08 03:20:13',NULL),(168,1,22,'Ward  15','2023-07-08 03:21:13',NULL),(169,1,22,'Ward  16','2023-07-08 03:21:29',NULL),(170,1,22,'Ward 17','2023-07-08 03:21:47',NULL),(171,1,29,'Ward  15','2023-07-08 03:26:46',NULL),(172,1,29,'Ward  17','2023-07-08 03:27:11','2023-07-08 03:40:56'),(173,1,29,'Ward  19','2023-07-08 03:27:30',NULL),(174,1,29,'Ward  21','2023-07-08 03:27:40',NULL),(175,1,29,'Ward  22','2023-07-08 03:28:04',NULL),(176,1,29,'Ward  24','2023-07-08 03:29:02','2023-07-08 03:48:36'),(177,1,29,'Ward  25','2023-07-08 03:29:19','2023-07-08 03:48:26'),(178,1,29,'Ward 26','2023-07-08 03:29:31','2023-07-08 03:48:05'),(179,1,29,'Ward 27','2023-07-08 03:29:51','2023-07-08 03:47:56'),(180,1,29,'Ward 28','2023-07-08 03:30:06','2023-07-08 03:47:45'),(181,1,3,'Ward 1','2023-07-08 03:31:08','2023-07-08 03:40:39'),(182,1,3,'Ward 2','2023-07-08 03:31:22','2023-07-08 03:40:27'),(183,1,3,'Ward 3','2023-07-08 03:31:37','2023-07-08 03:40:18'),(184,1,3,'Ward 4','2023-07-08 03:31:47','2023-07-08 03:39:23'),(185,1,3,'Ward 5','2023-07-08 03:32:02','2023-07-08 03:39:12'),(186,1,3,'Ward 9','2023-07-08 03:33:13','2023-07-08 03:39:06'),(187,1,3,'Ward 10','2023-07-08 03:33:25','2023-07-08 03:38:58'),(188,1,3,'Ward 11','2023-07-08 03:33:39','2023-07-08 03:38:50'),(189,1,3,'Ward  13','2023-07-08 03:33:55','2023-07-08 03:38:42'),(190,1,3,'Ward 14','2023-07-08 03:35:35','2023-07-08 03:38:32'),(191,1,3,'Vo Thi Sau ward','2023-07-08 03:38:06',NULL),(192,1,4,'Ward 1','2023-07-08 03:50:05',NULL),(193,1,4,'Ward 2','2023-07-08 03:50:22',NULL),(194,1,4,'Ward 3','2023-07-08 03:50:38',NULL),(195,1,4,'Ward 4','2023-07-08 03:50:50','2023-07-08 03:50:59'),(196,1,4,'Ward 5','2023-07-08 03:51:23',NULL),(197,1,4,'Ward 6','2023-07-08 03:51:41','2023-07-08 03:51:48'),(198,1,4,'Ward 8','2023-07-08 03:52:13',NULL),(199,1,4,'Ward 9','2023-07-08 03:52:29',NULL),(200,1,4,'Ward 10','2023-07-08 03:52:50','2023-07-08 03:52:56'),(201,1,4,'Ward 12','2023-07-08 03:53:21',NULL),(202,1,4,'Ward 13','2023-07-08 03:53:33','2023-07-08 03:53:44'),(203,1,4,'Ward 14','2023-07-08 03:54:06','2023-07-08 03:54:17'),(204,1,4,'Ward 15','2023-07-08 03:54:40',NULL),(205,1,4,'Ward 16','2023-07-08 03:54:57',NULL),(206,1,4,'Ward 18','2023-07-08 03:55:17',NULL),(207,1,5,'Ward 1','2023-07-08 03:56:20',NULL),(208,1,5,'Ward 2','2023-07-08 03:56:39',NULL),(209,1,5,'Ward 3','2023-07-08 03:57:06',NULL),(210,1,5,'Ward 4','2023-07-08 03:57:25',NULL),(211,1,5,'Ward 5','2023-07-08 03:57:41',NULL),(212,1,5,'Ward 6','2023-07-08 03:57:54',NULL),(213,1,5,'Ward 7','2023-07-08 03:58:34',NULL),(214,1,5,'Ward 8','2023-07-08 03:58:51',NULL),(215,1,5,'Ward 9','2023-07-08 03:59:14',NULL),(216,1,5,'Ward 10','2023-07-08 03:59:28',NULL),(217,1,5,'Ward 11','2023-07-08 03:59:43',NULL),(218,1,5,'Ward 12','2023-07-08 03:59:59',NULL),(219,1,5,'Ward 13','2023-07-08 04:00:14',NULL),(220,1,5,'Ward 14','2023-07-08 04:00:32',NULL),(221,1,6,'Ward 1','2023-07-08 04:01:35',NULL),(222,1,6,'Ward 2','2023-07-08 04:01:53',NULL),(223,1,6,'Ward 3','2023-07-08 04:02:05',NULL),(224,1,6,'Ward 4','2023-07-08 04:02:17',NULL),(225,1,6,'Ward 5','2023-07-08 04:02:36',NULL),(226,1,6,'Ward 6','2023-07-08 04:02:53',NULL),(227,1,6,'Ward 7','2023-07-08 04:03:07',NULL),(228,1,6,'Ward 8','2023-07-08 04:03:42',NULL),(229,1,6,'Ward 9','2023-07-08 04:04:10',NULL),(230,1,6,'Ward 10','2023-07-08 04:04:28',NULL),(231,1,6,'Ward 11','2023-07-08 04:04:46',NULL),(232,1,6,'Ward 12','2023-07-08 04:05:03',NULL),(233,1,6,'Ward 13','2023-07-08 04:05:21',NULL),(234,1,6,'Ward 14','2023-07-08 04:05:37',NULL),(235,1,7,'Binh Thuan ward','2023-07-08 04:08:39',NULL),(236,1,7,'Phu Thuan ward','2023-07-08 04:09:01',NULL),(237,1,7,'Tan Kieng ward','2023-07-08 04:09:34',NULL),(238,1,7,'Tan Phu ward','2023-07-08 04:09:47',NULL),(239,1,7,'Tan Thuan Dong ward','2023-07-08 04:10:15',NULL),(240,1,7,'Phu My ward','2023-07-08 04:10:36',NULL),(241,1,7,'Tan Hung ward','2023-07-08 04:10:52',NULL),(242,1,7,'Tan Phong ward','2023-07-08 04:11:17',NULL),(243,1,7,'Tan Quy ward','2023-07-08 04:11:34',NULL),(244,1,7,'Tan Thuan Tay ward','2023-07-08 04:11:58',NULL),(245,1,8,'Ward 1','2023-07-08 04:19:54',NULL),(246,1,8,'Ward 2','2023-07-08 04:20:16',NULL),(247,1,8,'Ward 3','2023-07-08 04:20:31',NULL),(248,1,8,'Ward 4','2023-07-08 04:20:48',NULL),(249,1,8,'Ward 5','2023-07-08 04:21:02',NULL),(250,1,8,'Ward 6','2023-07-08 04:21:15',NULL),(251,1,8,'Ward 7','2023-07-08 04:21:34',NULL),(252,1,8,'Ward 8','2023-07-08 04:21:48',NULL),(253,1,8,'Ward 9','2023-07-08 04:22:01',NULL),(254,1,8,'Ward 10','2023-07-08 04:22:11',NULL),(255,1,8,'Ward 11','2023-07-08 04:46:15',NULL),(256,1,8,'Ward 12','2023-07-08 04:46:41',NULL),(257,1,8,'Ward 13','2023-07-08 04:47:02',NULL),(258,1,8,'Ward 14','2023-07-08 04:48:32',NULL),(259,1,8,'Ward 15','2023-07-08 04:48:51',NULL),(260,1,8,'Ward 16','2023-07-08 04:49:11',NULL),(261,1,10,'Ward 1','2023-07-08 05:00:38',NULL),(262,1,10,'Ward 2','2023-07-08 05:01:00',NULL),(263,1,10,'Ward 4','2023-07-08 05:01:24',NULL),(264,1,10,'Ward 5','2023-07-08 05:01:42',NULL),(265,1,10,'Ward 6','2023-07-08 05:02:11',NULL),(266,1,10,'Ward 7','2023-07-08 05:02:38',NULL),(267,1,10,'Ward 8','2023-07-08 05:02:58',NULL),(268,1,10,'Ward 9','2023-07-08 05:03:17',NULL),(269,1,10,'Ward 10','2023-07-08 05:03:49',NULL),(270,1,10,'Ward 11','2023-07-08 05:04:13',NULL),(271,1,10,'Ward 12','2023-07-08 05:04:34',NULL),(272,1,10,'Ward 13','2023-07-08 05:04:51',NULL),(273,1,10,'Ward 14','2023-07-08 05:05:11',NULL),(274,1,10,'Ward 15','2023-07-08 05:05:32',NULL),(275,1,11,'Ward 1','2023-07-08 05:06:15',NULL),(276,1,11,'Ward 2','2023-07-08 05:07:16',NULL),(277,1,11,'Ward 3','2023-07-08 05:07:38',NULL),(278,1,11,'Ward 4','2023-07-08 05:07:55',NULL),(279,1,11,'Ward 5','2023-07-08 05:08:19',NULL),(280,1,11,'Ward 6','2023-07-08 05:08:37',NULL),(281,1,11,'Ward 7','2023-07-08 05:08:38',NULL),(282,1,11,'Ward 8','2023-07-08 05:08:39',NULL),(283,1,11,'Ward 9','2023-07-08 05:08:39',NULL),(284,1,11,'Ward 10','2023-07-08 05:08:39',NULL),(285,1,11,'Ward 11','2023-07-08 05:08:39',NULL),(286,1,11,'Ward 12','2023-07-08 05:08:39',NULL),(287,1,11,'Ward 13','2023-07-08 05:08:39',NULL),(288,1,11,'Ward 14','2023-07-08 05:08:40',NULL),(289,1,11,'Ward 15','2023-07-08 05:08:40',NULL),(290,1,11,'Ward 16','2023-07-08 05:11:54',NULL),(291,1,12,'An Phu Dong ward','2023-07-08 05:12:41',NULL),(292,1,12,'Hiep Thanh ward','2023-07-08 05:13:12',NULL),(293,1,12,'Tan Hung Thuan ward','2023-07-08 05:13:45',NULL),(294,1,12,'Tan Thoi Nhat ward','2023-07-08 05:14:08',NULL),(295,1,12,'Thanh Xuan ward','2023-07-08 05:14:32',NULL),(296,1,12,'Trung My Tay ward','2023-07-08 05:15:07',NULL),(297,1,12,'Dong Hung Thuan ward','2023-07-08 05:15:34',NULL),(298,1,12,'Tan Chanh Hiep ward','2023-07-08 05:16:12',NULL),(299,1,12,'Tan Thoi Hiep ward','2023-07-08 05:16:38',NULL),(300,1,12,'Thanh Loc ward','2023-07-08 05:17:08',NULL),(301,1,12,'Thoi An ward','2023-07-08 05:17:31',NULL);
/*!40000 ALTER TABLE `ship_communes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ship_districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ship_districts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `city_id` bigint(20) unsigned NOT NULL,
  `district_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ship_districts` WRITE;
/*!40000 ALTER TABLE `ship_districts` DISABLE KEYS */;
INSERT INTO `ship_districts` VALUES (1,1,'District 1','2023-06-25 04:29:24',NULL),(2,1,'District Thu Duc, 2, 9','2023-06-25 04:29:31','2023-07-08 04:57:24'),(3,1,'District 3','2023-06-25 04:29:37',NULL),(4,1,'District 4','2023-06-25 04:29:45',NULL),(5,1,'District 5','2023-06-25 04:30:33',NULL),(6,1,'District 6','2023-06-25 04:30:40',NULL),(7,1,'District 7','2023-06-25 04:30:46',NULL),(8,1,'District 8','2023-06-25 04:30:52',NULL),(10,1,'District 10','2023-06-25 04:31:04',NULL),(11,1,'District 11','2023-06-25 04:31:13',NULL),(12,1,'District 12','2023-06-25 04:31:18',NULL),(13,1,'Binh Chanh district','2023-06-25 04:31:27','2023-06-25 04:31:32'),(20,1,'Binh Tan district','2023-07-08 01:35:33',NULL),(21,1,'Tan Binh district','2023-07-08 01:35:56',NULL),(22,1,'Go Vap district','2023-07-08 01:36:19',NULL),(23,1,'Cu Chi district','2023-07-08 01:36:37',NULL),(24,1,'Tan Phu district','2023-07-08 01:37:16',NULL),(25,1,'Can Gio district','2023-07-08 01:37:28','2023-07-08 01:38:02'),(26,1,'Hoc Mon district','2023-07-08 01:37:45','2023-07-08 02:06:13'),(27,1,'Nha Be district','2023-07-08 01:38:29',NULL),(28,1,'Phu Nhuan district','2023-07-08 01:38:51',NULL),(29,1,'Binh Thanh district','2023-07-08 01:39:08',NULL),(30,3,'Cam Le district','2023-07-08 01:39:56',NULL),(31,3,'Lien Chieu district','2023-07-08 01:40:16',NULL),(32,3,'Son Tra district','2023-07-08 01:40:29',NULL),(33,3,'Hoa Vang district','2023-07-08 01:40:49',NULL),(34,3,'Hai Chau district','2023-07-08 01:41:05',NULL),(35,3,'Ngu Hanh Son district','2023-07-08 01:41:19',NULL),(36,3,'Thanh Khe district','2023-07-08 01:41:39',NULL),(37,3,'Hoang Sa district','2023-07-08 01:41:54',NULL),(38,2,'Ba Dinh district','2023-07-08 01:42:28',NULL),(39,2,'Cau Giay district','2023-07-08 01:42:47',NULL),(40,2,'Ha Dong district','2023-07-08 01:42:59',NULL),(41,2,'Hoang Kiem district','2023-07-08 01:43:14',NULL),(42,2,'Long Bien district','2023-07-08 01:43:37',NULL),(43,2,'Tay Ho district','2023-07-08 01:44:02',NULL),(44,2,'Ba Vi district','2023-07-08 01:44:13',NULL),(45,2,'Me Linh district','2023-07-08 01:44:59',NULL),(46,2,'Phu Xuyen','2023-07-08 01:45:09',NULL),(47,2,'Quoc Oai','2023-07-08 01:45:36',NULL),(48,2,'Thach That district','2023-07-08 01:46:01',NULL),(49,2,'Thanh Tri district','2023-07-08 01:46:18',NULL),(50,2,'Ung Hoa district','2023-07-08 01:46:33',NULL),(51,2,'Dong Da district','2023-07-08 01:47:00',NULL),(52,2,'Hai Ba Trung district','2023-07-08 01:47:16',NULL),(53,2,'Bac Tu Liem district','2023-07-08 01:47:35',NULL),(54,2,'Chuong My district','2023-07-08 01:47:54',NULL),(55,2,'Dong Anh district','2023-07-08 01:48:09',NULL),(56,2,'Hoai Duc district','2023-07-08 01:48:31',NULL),(57,2,'Soc Son district','2023-07-08 01:48:41',NULL),(58,2,'My Duc district','2023-07-08 01:49:00',NULL),(59,2,'Phuc Tho district','2023-07-08 01:49:20',NULL),(60,2,'Thanh Oai district','2023-07-08 01:49:46',NULL),(61,2,'Thuong Tin district','2023-07-08 01:50:01',NULL);
/*!40000 ALTER TABLE `ship_districts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `support_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_us_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hours` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pinterest` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'upload/logo/1769647990657590_logo.svg','1900 - 999','1900 900','nest@gmail.com','Ho Chi Minh city, Viet Nam.','09:00 - 21:00, Mon - Sun','https://www.facebook.com/laiminhkiet752','https://twitter.com/Kiet070502','https://www.youtube.com/channel/UCx7yneP9y9BDz776MzIkdqg','https://www.instagram.com/kiet_7522/','https://www.pinterest.com/kietminh070502/','Nest. 2023 All rights reserved','2023-06-25 04:34:30','2023-06-25 04:37:17');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sliders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slider_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slider_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('show','hide') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'show',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
INSERT INTO `sliders` VALUES (1,'Fresh Vegetables Big Discount','Save up to 50% off on your first order','upload/slider/1769647113915006_slider.png','show','2023-06-25 04:23:22',NULL),(2,'Don’t miss amazing grocery deals','Sign up for the daily newsletter','upload/slider/1769647122929714_slider.png','show','2023-06-25 04:23:30','2023-07-05 00:36:15');
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `smtp_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smtp_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mailer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `encryption` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `smtp_settings` WRITE;
/*!40000 ALTER TABLE `smtp_settings` DISABLE KEYS */;
INSERT INTO `smtp_settings` VALUES (1,'smtp','smtp.gmail.com','587','no.reply.nestshop@gmail.com','cakvhzwnbgksdjuk','tls','no.reply.nestshop@gmail.com','NestShop','2023-07-01 15:24:08','2023-07-03 14:02:02');
/*!40000 ALTER TABLE `smtp_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `subcategory_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_categories_subcategory_name_unique` (`subcategory_name`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
INSERT INTO `sub_categories` VALUES (3,3,'TUNA','tuna','2023-06-25 03:54:57','2023-07-08 12:31:17'),(4,3,'INK PELLETS','ink-pellets','2023-06-25 03:55:14','2023-07-08 14:23:15'),(5,5,'DOG\'S FOOD','dog\'s-food','2023-06-25 03:55:25','2023-06-25 03:55:44'),(6,5,'CAT\'S FOOD','cat\'s-food','2023-06-25 03:55:53','2023-06-25 03:55:53'),(7,2,'GRAPE','grape','2023-06-25 03:57:19','2023-06-25 03:57:19'),(8,2,'STRAWBERRY','strawberry','2023-06-25 03:57:31','2023-06-25 03:57:31'),(9,7,'DUCK\'S EGG','duck\'s-egg','2023-06-25 03:57:50','2023-07-05 07:40:35'),(10,7,'QUAIL EGGS','quail-eggs','2023-06-25 03:58:13','2023-06-25 03:58:13'),(11,6,'BOX FORM','box-form','2023-06-25 03:58:33','2023-07-08 13:57:29'),(12,6,'BAG FORM','bag-form','2023-06-25 03:58:45','2023-07-08 13:57:10'),(13,1,'BROCCOLI','broccoli','2023-06-25 07:01:24','2023-06-25 07:01:24'),(14,1,'SPINACH','spinach','2023-06-25 07:01:44','2023-06-25 07:01:44'),(15,1,'POWDER FORM','powder-form','2023-07-08 12:44:07','2023-07-08 12:53:36'),(16,2,'BANANA','banana','2023-07-08 12:57:18','2023-07-08 12:57:18'),(17,2,'WATERMELON','watermelon','2023-07-08 13:03:25','2023-07-08 13:03:25'),(21,3,'FISH PELLETS','fish-pellets','2023-07-08 14:25:17','2023-07-08 14:25:17'),(24,4,'COCA COLA','coca-cola','2023-07-10 02:41:01','2023-07-10 02:41:01'),(25,4,'MIRINDA','mirinda','2023-07-10 02:41:19','2023-07-10 02:41:19'),(26,4,'PEPSI','pepsi','2023-07-10 02:41:41','2023-07-10 02:41:41'),(27,4,'C2','c2','2023-07-10 02:42:16','2023-07-10 02:42:16');
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subscribers` WRITE;
/*!40000 ALTER TABLE `subscribers` DISABLE KEYS */;
INSERT INTO `subscribers` VALUES (1,'laiminhkiet07052002@gmail.com','','Active','2023-07-04 13:56:02','2023-07-04 13:58:35');
/*!40000 ALTER TABLE `subscribers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('admin','vendor','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `last_seen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_phone_unique` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'SuperAdmin','superadmin','kietminh070502@gmail.com','2023-06-25 04:38:43','$2y$10$Rydofv3UiM3vGFSVikxXl.rjK2Iat5no1SarKG3uwOtqyarwrSTdW','1769826218799972_admin.jpg','0376707091','Sailing Tower, 111A Pasteur Street, District 1, Ho Chi Minh City',NULL,NULL,'admin','active','2023-07-12 10:33:14','0161d8433589e0396bb33a60cf61b2521b9803d0171646524bdbcdeababd12cc',NULL,'2023-06-25 03:22:55','2023-07-12 03:33:14'),(3,'Minh Kiet','laiminhkiet','laiminhkiet07052002@gmail.com','2023-06-25 04:38:43','$2y$10$8ZR1lLdNUS9ivYtg4S.us.DfWky9YsOsgsIfWp7PNB9ssoV0o3UKK','1769648355286070_user.jpg','0793442309',NULL,NULL,NULL,'user','active','2023-07-12 10:20:51',NULL,'EoPkL7mUbINftGdWlceh0JUIvRcjRjru6DyPAsL2ht3Vtz2IwZSsiqxnzDdR','2023-06-25 03:22:56','2023-07-12 03:20:51'),(4,'Admin','admin','admin@gmail.com','2023-06-29 05:42:13','$2y$10$pVHqEbnEGq.kaMSKbQSG/u347Eyz4Osnxrz/keVtWpyaLVjuy0KBm','1769820137253465_admin.png','0998874321','Flat Number 1134, 136 Ho Tung Mau street, Mai Dich ward, Cau Giay District, Ha Noi',NULL,NULL,'admin','active','2023-07-05 10:56:11',NULL,NULL,'2023-06-27 02:06:54','2023-07-11 06:20:05'),(18,'Hoang Phuc','lenguyenhoangphuc','hoangphuc270502@gmail.com','2023-07-11 08:35:10','$2y$10$SJo/IT9tFjJHPs24O5ZL2u.LS/KYO.3X5YLDTq8DBnlVhCNno8nqe',NULL,'0332964321',NULL,NULL,NULL,'user','active','2023-07-11 22:18:26',NULL,NULL,'2023-07-11 08:33:33','2023-07-11 15:18:26');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `wishlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wishlists` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `wishlists` WRITE;
/*!40000 ALTER TABLE `wishlists` DISABLE KEYS */;
INSERT INTO `wishlists` VALUES (12,3,40,'2023-07-12 02:42:53',NULL);
/*!40000 ALTER TABLE `wishlists` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


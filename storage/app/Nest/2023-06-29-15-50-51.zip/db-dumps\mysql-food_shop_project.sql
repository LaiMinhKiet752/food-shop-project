
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `banner_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('show','hide') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'show',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
INSERT INTO `banners` VALUES (1,'The Best Organic Products Online','upload/banner/1769647176332299_banner.png','show','2023-06-25 04:24:21',NULL),(2,'Everyday Fresh & Clean With Our Products','upload/banner/1769647185216280_banner.png','show','2023-06-25 04:24:29',NULL),(3,'Make your Breakfast Healthy and Easy','upload/banner/1769647192479345_banner.png','show','2023-06-25 04:24:36',NULL);
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blog_category_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
INSERT INTO `blog_categories` VALUES (1,'Pet Foods','pet-foods','2023-06-25 09:44:09',NULL),(2,'Fresh Fruit','fresh-fruit','2023-06-25 09:44:21',NULL),(3,'Baking material','baking-material','2023-06-25 09:45:19',NULL),(4,'Milk & Dairies','milk-&-dairies','2023-06-25 09:45:33',NULL);
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blog_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_post_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blog_comments` WRITE;
/*!40000 ALTER TABLE `blog_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `post_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_short_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_long_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `views` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blog_posts` WRITE;
/*!40000 ALTER TABLE `blog_posts` DISABLE KEYS */;
INSERT INTO `blog_posts` VALUES (1,4,'Best smartwatch 2022: the top wearables you can buy today','best-smartwatch-2022:-the-top-wearables-you-can-buy-today','upload/blog/1769667493194487.png','Lorem ipsum dolor sit, amet consectetur adipisicing elit. \r\nAnimi, quas veniam? Quisquam aliquid ipsum alias, ipsa quasi veritatis porro quidem, fuga deserunt magnam illum rem quod.','<p class=\"single-excerpt\">Helping everyone live happier, healthier lives at home through their kitchen. Kitchn is a daily food magazine on the Web celebrating life in the kitchen through home cooking and kitchen intelligence.</p>\r\n<p>We\'ve reviewed and ranked all of the best smartwatches on the market right now, and we\'ve made a definitive list of the top 10 devices you can buy today. One of the 10 picks below may just be your perfect next smartwatch.</p>\r\n<p>Those top-end wearables span from the Apple Watch to Fitbits, Garmin watches to Tizen-sporting Samsung watches. There\'s also Wear OS which is Google\'s own wearable operating system in the vein of Apple\'s watchOS - you&rsquo;ll see it show up in a lot of these devices.</p>\r\n<h5 class=\"mt-50\">Lorem ipsum dolor sit amet cons</h5>\r\n<p>Throughout our review process, we look at the design, features, battery life, spec, price and more for each smartwatch, rank it against the competition and enter it into the list you\'ll find below.</p>\r\n<p><img class=\"mb-30\" src=\"assets/imgs/blog/blog-21.png\" alt=\"\"></p>\r\n<p>Tortor, lobortis semper viverra ac, molestie tortor laoreet amet euismod et diam quis aliquam consequat porttitor integer a nisl, in faucibus nunc et aenean turpis dui dignissim nec scelerisque ullamcorper eu neque, augue quam quis lacus pretium eros est amet turpis nunc in turpis massa et eget facilisis ante molestie penatibus dolor volutpat, porta pellentesque scelerisque at ornare dui tincidunt cras feugiat tempor lectus</p>\r\n<blockquote>\r\n<p>Integer eu faucibus&nbsp;<a href=\"#\">dolor</a><sup><a href=\"#\">[5]</a></sup>. Ut venenatis tincidunt diam elementum imperdiet. Etiam accumsan semper nisl eu congue. Sed aliquam magna erat, ac eleifend lacus rhoncus in.</p>\r\n</blockquote>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet id enim, libero sit. Est donec lobortis cursus amet, cras elementum libero convallis feugiat. Nulla faucibus facilisi tincidunt a arcu, sem donec sed sed. Tincidunt morbi scelerisque lectus non. At leo mauris, vel augue. Facilisi diam consequat amet, commodo lorem nisl, odio malesuada cras. Tempus lectus sed libero viverra ut. Facilisi rhoncus elit sit sit.</p>',12,'2023-06-25 09:47:17','2023-06-28 00:53:18'),(2,3,'The Easy Italian Chicken Dinner I Make Over and Over Again','the-easy-italian-chicken-dinner-i-make-over-and-over-again','upload/blog/1769667543334368.png','Lorem ipsum dolor sit, amet consectetur adipisicing elit. \r\nAnimi, quas veniam? Quisquam aliquid ipsum alias, ipsa quasi veritatis porro quidem, fuga deserunt magnam illum rem quod.','<p class=\"single-excerpt\">Helping everyone live happier, healthier lives at home through their kitchen. Kitchn is a daily food magazine on the Web celebrating life in the kitchen through home cooking and kitchen intelligence.</p>\r\n<p>We\'ve reviewed and ranked all of the best smartwatches on the market right now, and we\'ve made a definitive list of the top 10 devices you can buy today. One of the 10 picks below may just be your perfect next smartwatch.</p>\r\n<p>Those top-end wearables span from the Apple Watch to Fitbits, Garmin watches to Tizen-sporting Samsung watches. There\'s also Wear OS which is Google\'s own wearable operating system in the vein of Apple\'s watchOS - you&rsquo;ll see it show up in a lot of these devices.</p>\r\n<h5 class=\"mt-50\">Lorem ipsum dolor sit amet cons</h5>\r\n<p>Throughout our review process, we look at the design, features, battery life, spec, price and more for each smartwatch, rank it against the competition and enter it into the list you\'ll find below.</p>\r\n<p><img class=\"mb-30\" src=\"assets/imgs/blog/blog-21.png\" alt=\"\"></p>\r\n<p>Tortor, lobortis semper viverra ac, molestie tortor laoreet amet euismod et diam quis aliquam consequat porttitor integer a nisl, in faucibus nunc et aenean turpis dui dignissim nec scelerisque ullamcorper eu neque, augue quam quis lacus pretium eros est amet turpis nunc in turpis massa et eget facilisis ante molestie penatibus dolor volutpat, porta pellentesque scelerisque at ornare dui tincidunt cras feugiat tempor lectus</p>\r\n<blockquote>\r\n<p>Integer eu faucibus&nbsp;<a href=\"#\">dolor</a><sup><a href=\"#\">[5]</a></sup>. Ut venenatis tincidunt diam elementum imperdiet. Etiam accumsan semper nisl eu congue. Sed aliquam magna erat, ac eleifend lacus rhoncus in.</p>\r\n</blockquote>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet id enim, libero sit. Est donec lobortis cursus amet, cras elementum libero convallis feugiat. Nulla faucibus facilisi tincidunt a arcu, sem donec sed sed. Tincidunt morbi scelerisque lectus non. At leo mauris, vel augue. Facilisi diam consequat amet, commodo lorem nisl, odio malesuada cras. Tempus lectus sed libero viverra ut. Facilisi rhoncus elit sit sit.</p>',11,'2023-06-25 09:48:05','2023-06-25 09:48:59'),(3,1,'I Tried 38 Different Bottles of Mustard — These Are the Ones I’ll Buy Again','i-tried-38-different-bottles-of-mustard-—-these-are-the-ones-i’ll-buy-again','upload/blog/1769667585655316.png','Lorem ipsum dolor sit, amet consectetur adipisicing elit. \r\nAnimi, quas veniam? Quisquam aliquid ipsum alias, ipsa quasi veritatis porro quidem, fuga deserunt magnam illum rem quod.','<p class=\"single-excerpt\">Helping everyone live happier, healthier lives at home through their kitchen. Kitchn is a daily food magazine on the Web celebrating life in the kitchen through home cooking and kitchen intelligence.</p>\r\n<p>We\'ve reviewed and ranked all of the best smartwatches on the market right now, and we\'ve made a definitive list of the top 10 devices you can buy today. One of the 10 picks below may just be your perfect next smartwatch.</p>\r\n<p>Those top-end wearables span from the Apple Watch to Fitbits, Garmin watches to Tizen-sporting Samsung watches. There\'s also Wear OS which is Google\'s own wearable operating system in the vein of Apple\'s watchOS - you&rsquo;ll see it show up in a lot of these devices.</p>\r\n<h5 class=\"mt-50\">Lorem ipsum dolor sit amet cons</h5>\r\n<p>Throughout our review process, we look at the design, features, battery life, spec, price and more for each smartwatch, rank it against the competition and enter it into the list you\'ll find below.</p>\r\n<p><img class=\"mb-30\" src=\"assets/imgs/blog/blog-21.png\" alt=\"\"></p>\r\n<p>Tortor, lobortis semper viverra ac, molestie tortor laoreet amet euismod et diam quis aliquam consequat porttitor integer a nisl, in faucibus nunc et aenean turpis dui dignissim nec scelerisque ullamcorper eu neque, augue quam quis lacus pretium eros est amet turpis nunc in turpis massa et eget facilisis ante molestie penatibus dolor volutpat, porta pellentesque scelerisque at ornare dui tincidunt cras feugiat tempor lectus</p>\r\n<blockquote>\r\n<p>Integer eu faucibus&nbsp;<a href=\"#\">dolor</a><sup><a href=\"#\">[5]</a></sup>. Ut venenatis tincidunt diam elementum imperdiet. Etiam accumsan semper nisl eu congue. Sed aliquam magna erat, ac eleifend lacus rhoncus in.</p>\r\n</blockquote>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet id enim, libero sit. Est donec lobortis cursus amet, cras elementum libero convallis feugiat. Nulla faucibus facilisi tincidunt a arcu, sem donec sed sed. Tincidunt morbi scelerisque lectus non. At leo mauris, vel augue. Facilisi diam consequat amet, commodo lorem nisl, odio malesuada cras. Tempus lectus sed libero viverra ut. Facilisi rhoncus elit sit sit.</p>',12,'2023-06-25 09:48:45',NULL),(4,2,'How I Prep a Week of Absolutely Simple Summer Meals in Just 1 Hour','how-i-prep-a-week-of-absolutely-simple-summer-meals-in-just-1-hour','upload/blog/1769667629483573.png','Lorem ipsum dolor sit, amet consectetur adipisicing elit. \r\nAnimi, quas veniam? Quisquam aliquid ipsum alias, ipsa quasi veritatis porro quidem, fuga deserunt magnam illum rem quod.','<p class=\"single-excerpt\">Helping everyone live happier, healthier lives at home through their kitchen. Kitchn is a daily food magazine on the Web celebrating life in the kitchen through home cooking and kitchen intelligence.</p>\r\n<p>We\'ve reviewed and ranked all of the best smartwatches on the market right now, and we\'ve made a definitive list of the top 10 devices you can buy today. One of the 10 picks below may just be your perfect next smartwatch.</p>\r\n<p>Those top-end wearables span from the Apple Watch to Fitbits, Garmin watches to Tizen-sporting Samsung watches. There\'s also Wear OS which is Google\'s own wearable operating system in the vein of Apple\'s watchOS - you&rsquo;ll see it show up in a lot of these devices.</p>\r\n<h5 class=\"mt-50\">Lorem ipsum dolor sit amet cons</h5>\r\n<p>Throughout our review process, we look at the design, features, battery life, spec, price and more for each smartwatch, rank it against the competition and enter it into the list you\'ll find below.</p>\r\n<p><img class=\"mb-30\" src=\"assets/imgs/blog/blog-21.png\" alt=\"\"></p>\r\n<p>Tortor, lobortis semper viverra ac, molestie tortor laoreet amet euismod et diam quis aliquam consequat porttitor integer a nisl, in faucibus nunc et aenean turpis dui dignissim nec scelerisque ullamcorper eu neque, augue quam quis lacus pretium eros est amet turpis nunc in turpis massa et eget facilisis ante molestie penatibus dolor volutpat, porta pellentesque scelerisque at ornare dui tincidunt cras feugiat tempor lectus</p>\r\n<blockquote>\r\n<p>Integer eu faucibus&nbsp;<a href=\"#\">dolor</a><sup><a href=\"#\">[5]</a></sup>. Ut venenatis tincidunt diam elementum imperdiet. Etiam accumsan semper nisl eu congue. Sed aliquam magna erat, ac eleifend lacus rhoncus in.</p>\r\n</blockquote>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet id enim, libero sit. Est donec lobortis cursus amet, cras elementum libero convallis feugiat. Nulla faucibus facilisi tincidunt a arcu, sem donec sed sed. Tincidunt morbi scelerisque lectus non. At leo mauris, vel augue. Facilisi diam consequat amet, commodo lorem nisl, odio malesuada cras. Tempus lectus sed libero viverra ut. Facilisi rhoncus elit sit sit.</p>',13,'2023-06-25 09:49:27',NULL);
/*!40000 ALTER TABLE `blog_posts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_brand_name_unique` (`brand_name`),
  UNIQUE KEY `brands_brand_email_unique` (`brand_email`),
  UNIQUE KEY `brands_brand_phone_unique` (`brand_phone`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'Pepsi','pepsi','upload/brand/1769643917736944_brand.png','pepsi@gmail.com','1122334455','Number 930, Hoang Anh Gia Lai Apartment Block, Nguyen Thi Thap Street, District 7, Ho Chi Minh City','2023-06-25 03:28:46','2023-06-25 03:32:33',NULL),(2,'Oreo','oreo','upload/brand/1769937386676275_brand.png','oreo@gmail.com','5544332211','Room No.8, Keangnam Building, Pham Hung Street, Nam Tu Liem District, Ha Noi City','2023-06-28 09:17:07','2023-06-28 09:17:07',NULL);
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_category_name_unique` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'VEGETABLE','vegetable','upload/category/1769644191460967_category.svg','2023-06-25 03:36:54','2023-06-25 03:36:54',NULL),(2,'FRUIT','fruit','upload/category/1769644295037590_category.svg','2023-06-25 03:38:33','2023-06-25 03:38:33',NULL),(3,'SEAFOOD','seafood','upload/category/1769644387569403_category.svg','2023-06-25 03:40:01','2023-06-25 03:40:01',NULL),(4,'SOFT DRINK','soft-drink','upload/category/1769644485532351_category.svg','2023-06-25 03:41:35','2023-06-25 03:41:35',NULL),(5,'PET FOODS','pet-foods','upload/category/1769644645213784_category.svg','2023-06-25 03:44:07','2023-06-25 03:44:07',NULL),(6,'CAKE','cake','upload/category/1769644789812491_category.svg','2023-06-25 03:46:25','2023-06-25 03:46:25',NULL),(7,'EGGS','eggs','upload/category/1769644846626349_category.svg','2023-06-25 03:47:19','2023-06-25 03:49:03',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `compares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compares` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `compares` WRITE;
/*!40000 ALTER TABLE `compares` DISABLE KEYS */;
/*!40000 ALTER TABLE `compares` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coupon_discount` int(11) NOT NULL,
  `coupon_validity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupons_coupon_code_unique` (`coupon_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES (1,'NEST',50,'2024-05-07',1,'2023-06-25 04:28:55',NULL,NULL),(2,'NESTSHOP23',40,'2023-06-30',1,'2023-06-25 07:28:21',NULL,NULL);
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_05_02_184500_create_brands_table',2),(6,'2023_05_04_094822_create_categories_table',3),(7,'2023_05_05_010505_create_sub_categories_table',3),(8,'2023_05_09_160008_create_products_table',4),(9,'2023_05_09_161259_create_multi_images_table',4),(10,'2023_05_15_074747_create_sliders_table',5),(11,'2023_05_15_100021_create_banners_table',5),(12,'2023_05_27_063309_create_wishlists_table',6),(13,'2023_05_29_141018_create_compares_table',7),(14,'2023_06_03_082224_create_coupons_table',8),(15,'2023_06_03_133542_create_ship_cities_table',9),(16,'2023_06_03_133911_create_ship_districts_table',9),(17,'2023_06_03_134047_create_ship_communes_table',9),(20,'2023_06_18_105634_create_blog_posts_table',10),(21,'2023_06_18_151251_create_blog_categories_table',10),(22,'2023_06_19_114428_create_blog_comments_table',10),(23,'2023_06_20_205544_create_reviews_table',11),(24,'2023_06_21_222234_create_site_settings_table',12),(25,'2023_06_22_074303_create_seos_table',13),(26,'2023_06_24_082558_create_permission_tables',14),(35,'2023_06_06_210147_create_orders_table',15),(36,'2023_06_06_211501_create_order_details_table',15),(37,'2023_06_27_211102_create_notifications_table',16);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(2,'App\\Models\\User',4);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `multi_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `photo_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `multi_images` WRITE;
/*!40000 ALTER TABLE `multi_images` DISABLE KEYS */;
INSERT INTO `multi_images` VALUES (1,1,'upload/products/multiple_images/1769645841134588_product.jpg','2023-06-25 04:03:08',NULL),(2,1,'upload/products/multiple_images/1769645841444253_product.jpg','2023-06-25 04:03:08',NULL),(3,2,'upload/products/multiple_images/1769646355055594_product.jpg','2023-06-25 04:11:18',NULL),(4,2,'upload/products/multiple_images/1769646355351049_product.jpg','2023-06-25 04:11:18',NULL),(5,3,'upload/products/multiple_images/1769646606327209_product.jpg','2023-06-25 04:15:17',NULL),(6,3,'upload/products/multiple_images/1769646606566919_product.jpg','2023-06-25 04:15:18',NULL),(7,4,'upload/products/multiple_images/1769646841238173_product.jpg','2023-06-25 04:19:01',NULL),(8,4,'upload/products/multiple_images/1769646841482897_product.jpg','2023-06-25 04:19:02',NULL),(9,5,'upload/products/multiple_images/1769647032297925_product.jpg','2023-06-25 04:22:04',NULL),(10,5,'upload/products/multiple_images/1769647032596917_product.jpg','2023-06-25 04:22:04',NULL),(11,6,'upload/products/multiple_images/1769667856426063_product.jpg','2023-06-25 09:53:03',NULL),(12,6,'upload/products/multiple_images/1769667856668663_product.jpg','2023-06-25 09:53:03',NULL),(13,7,'upload/products/multiple_images/1769759176397647_product.jpg','2023-06-26 10:04:33',NULL),(14,7,'upload/products/multiple_images/1769759176691082_product.jpg','2023-06-26 10:04:33',NULL),(15,8,'upload/products/multiple_images/1769759500470366_product.jpg','2023-06-26 10:09:42',NULL),(16,8,'upload/products/multiple_images/1769759500751285_product.jpg','2023-06-26 10:09:42',NULL),(17,9,'upload/products/multiple_images/1769759624977577_product.jpg','2023-06-26 10:11:40',NULL),(18,9,'upload/products/multiple_images/1769759625221138_product.jpg','2023-06-26 10:11:41',NULL),(19,10,'upload/products/multiple_images/1769937510319194_product.jpg','2023-06-28 09:19:05',NULL),(20,10,'upload/products/multiple_images/1769937510562920_product.jpg','2023-06-28 09:19:05',NULL),(21,11,'upload/products/multiple_images/1769937676689340_product.jpg','2023-06-28 09:21:44',NULL);
/*!40000 ALTER TABLE `multi_images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('1dd0565e-0c6e-419c-8534-26e359d40a42','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\"}','2023-06-28 14:53:35','2023-06-28 01:07:01','2023-06-28 14:53:35'),('262437a1-5d81-4a43-93be-c9fdf08eeba6','App\\Notifications\\VendorRegisterNotification','App\\Models\\User',4,'{\"message\":\"A request to become a vendor\"}','2023-06-28 14:53:35','2023-06-28 01:29:00','2023-06-28 14:53:35'),('28037f80-71ca-447f-8591-6be8f0529411','App\\Notifications\\VendorRegisterNotification','App\\Models\\User',1,'{\"message\":\"A request to become a vendor\"}','2023-06-28 01:29:12','2023-06-28 01:29:00','2023-06-28 01:29:12'),('29113c8e-4268-4e67-8713-976b77d246fb','App\\Notifications\\VendorDisapproveNotification','App\\Models\\User',7,'{\"message\":\"Your account has been disapproved\"}','2023-06-28 02:18:47','2023-06-28 02:18:25','2023-06-28 02:18:47'),('2d89dee9-7158-44c8-ba88-894ab7037352','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',1,'{\"message\":\"A new order has been placed\"}','2023-06-28 01:08:01','2023-06-28 01:07:01','2023-06-28 01:08:01'),('30f7c738-7b9b-4a41-8c08-f847133c7939','App\\Notifications\\UserRegisterNotification','App\\Models\\User',1,'{\"message\":\"A new account registered\"}','2023-06-28 01:40:30','2023-06-28 01:40:15','2023-06-28 01:40:30'),('3d05f16b-f0d2-4411-9439-a5e700cc87de','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',1,'{\"message\":\"A new order has been placed\"}','2023-06-29 02:05:40','2023-06-29 01:48:45','2023-06-29 02:05:40'),('4619e296-4867-4d62-9cc1-cec864e90d78','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\"}','2023-06-28 14:53:35','2023-06-28 12:20:40','2023-06-28 14:53:35'),('5a01b769-5816-4062-afb2-2b7f6ba47e5d','App\\Notifications\\VendorDisapproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been disapproved\"}','2023-06-28 02:09:39','2023-06-28 02:09:35','2023-06-28 02:09:39'),('718664ed-06a2-4e50-aec9-43155a259c67','App\\Notifications\\UserRegisterNotification','App\\Models\\User',4,'{\"message\":\"A new account registered\"}','2023-06-28 14:53:35','2023-06-28 01:40:15','2023-06-28 14:53:35'),('885e417e-d4c0-4614-b6bf-3c4e7fcabffc','App\\Notifications\\VendorApproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been approved\"}','2023-06-28 02:05:33','2023-06-28 02:05:30','2023-06-28 02:05:33'),('a4914a84-7f86-4ca1-819c-67129c9e0966','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',1,'{\"message\":\"A new order has been placed\"}','2023-06-29 02:05:40','2023-06-29 01:48:41','2023-06-29 02:05:40'),('b51aa72d-291c-4228-bb99-036bdc4dc597','App\\Notifications\\VendorApproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been approved\"}','2023-06-28 02:03:25','2023-06-28 02:03:14','2023-06-28 02:03:25'),('c107d7b4-533a-4509-a11d-d5908789f024','App\\Notifications\\VendorApproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been approved\"}','2023-06-28 02:18:32','2023-06-28 02:16:23','2023-06-28 02:18:32'),('c2dbe3bc-94ec-450c-9ee2-61bf43cd8dd9','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\"}','2023-06-29 01:53:13','2023-06-29 01:48:41','2023-06-29 01:53:13'),('cb58d10d-f39a-4591-b6f2-df5304340b80','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',1,'{\"message\":\"A new order has been placed\"}','2023-06-28 14:33:51','2023-06-28 12:20:40','2023-06-28 14:33:51'),('e0b169f1-8b8b-487d-acf1-9c558fcee5ee','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\"}','2023-06-29 01:53:13','2023-06-29 01:48:45','2023-06-29 01:53:13'),('e7b66f2b-17fd-4df2-9b49-e05ebb442e14','App\\Notifications\\VendorApproveNotification','App\\Models\\User',7,'{\"message\":\"Your account has been approved\"}','2023-06-28 02:02:39','2023-06-28 02:02:31','2023-06-28 02:02:39'),('ec4aa554-98f6-41bc-9e62-3dfb8ef4e747','App\\Notifications\\OrderCompleteNotification','App\\Models\\User',4,'{\"message\":\"A new order has been placed\"}','2023-06-27 15:08:26','2023-06-27 14:37:24','2023-06-27 15:08:26'),('f15b04fb-47dd-441d-8894-1a29bac93392','App\\Notifications\\VendorApproveNotification','App\\Models\\User',7,'{\"message\":\"Your account has been approved\"}','2023-06-28 02:19:05','2023-06-28 02:19:02','2023-06-28 02:19:05'),('f3f7f49f-41a8-4901-9b63-5c2a822f71ad','App\\Notifications\\VendorApproveNotification','App\\Models\\User',7,'{\"message\":\"Your account has been approved\"}','2023-06-28 02:05:43','2023-06-28 02:03:14','2023-06-28 02:05:43'),('f8db5194-6762-40b4-b8be-0d40c49bec05','App\\Notifications\\VendorApproveNotification','App\\Models\\User',2,'{\"message\":\"Your account has been approved\"}','2023-06-28 02:03:25','2023-06-28 02:02:31','2023-06-28 02:03:25');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `vendor_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `price` double(8,2) NOT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` double(8,2) DEFAULT NULL,
  `total` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_details_order_id_foreign` (`order_id`),
  CONSTRAINT `order_details_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_details` WRITE;
/*!40000 ALTER TABLE `order_details` DISABLE KEYS */;
INSERT INTO `order_details` VALUES (1,1,1,'2',6,10.30,'5',0.00,51.50,'2023-06-26 08:19:30',NULL),(2,1,1,NULL,5,15.00,'2',0.00,30.00,'2023-06-26 08:19:30',NULL),(3,1,1,NULL,4,5.50,'3',0.00,16.50,'2023-06-26 08:19:30',NULL),(4,1,1,NULL,3,12.45,'4',0.00,49.80,'2023-06-26 08:19:30',NULL),(5,1,1,NULL,2,10.50,'1',0.00,10.50,'2023-06-26 08:19:30',NULL),(6,1,1,NULL,1,15.50,'5',0.00,77.50,'2023-06-26 08:19:30',NULL),(7,2,1,NULL,1,15.50,'1',0.00,15.50,'2023-06-26 08:23:54',NULL),(8,2,1,NULL,2,10.50,'1',0.00,10.50,'2023-06-26 08:23:54',NULL),(9,2,1,NULL,3,12.45,'1',0.00,12.45,'2023-06-26 08:23:54',NULL),(10,2,1,NULL,4,5.50,'1',0.00,5.50,'2023-06-26 08:23:54',NULL),(11,2,1,NULL,5,15.00,'1',0.00,15.00,'2023-06-26 08:23:54',NULL),(12,3,1,NULL,5,15.00,'1',7.50,7.50,'2023-06-26 08:28:10',NULL),(13,3,1,'2',6,10.30,'1',5.15,5.15,'2023-06-26 08:28:10',NULL),(14,3,1,NULL,1,15.50,'1',7.75,7.75,'2023-06-26 08:28:10',NULL),(15,4,1,NULL,2,10.50,'1',0.00,10.50,'2023-06-26 08:29:44',NULL),(16,4,1,NULL,3,12.45,'1',0.00,12.45,'2023-06-26 08:29:44',NULL),(17,5,1,'2',6,10.30,'5',4.12,20.60,'2023-06-26 08:31:59',NULL),(18,5,1,NULL,1,15.50,'5',6.20,31.00,'2023-06-26 08:31:59',NULL),(19,6,1,'2',6,10.30,'1',5.15,5.15,'2023-06-26 08:42:18',NULL),(20,6,1,NULL,1,15.50,'1',7.75,7.75,'2023-06-26 08:42:18',NULL),(21,6,1,NULL,4,5.50,'1',2.75,2.75,'2023-06-26 08:42:18',NULL),(22,7,1,'2',6,10.30,'3',0.00,30.90,'2023-06-26 08:43:18',NULL),(23,7,1,NULL,5,15.00,'3',0.00,45.00,'2023-06-26 08:43:18',NULL),(24,7,1,NULL,3,12.45,'3',0.00,37.35,'2023-06-26 08:43:18',NULL),(25,8,1,'2',9,23.00,'1',11.50,11.50,'2023-06-27 14:37:18',NULL),(26,8,1,'2',8,13.50,'2',6.75,13.50,'2023-06-27 14:37:18',NULL),(27,8,1,'2',7,10.00,'3',5.00,15.00,'2023-06-27 14:37:18',NULL),(28,8,1,'2',6,10.30,'4',5.15,20.60,'2023-06-27 14:37:18',NULL),(29,9,1,'2',9,23.00,'2',0.00,46.00,'2023-06-28 01:06:56',NULL),(30,9,1,'2',8,13.50,'2',0.00,27.00,'2023-06-28 01:06:56',NULL),(31,9,1,NULL,2,10.50,'2',0.00,21.00,'2023-06-28 01:06:56',NULL),(32,9,1,NULL,1,15.50,'2',0.00,31.00,'2023-06-28 01:06:56',NULL),(33,10,2,'2',10,10.00,'1',0.00,10.00,'2023-06-28 12:20:35',NULL),(34,10,1,'2',9,35.00,'1',0.00,35.00,'2023-06-28 12:20:35',NULL),(35,10,1,'2',7,30.00,'1',0.00,30.00,'2023-06-28 12:20:35',NULL),(36,10,2,'2',11,25.00,'1',0.00,25.00,'2023-06-28 12:20:35',NULL),(37,11,1,NULL,3,12.45,'6',0.00,74.70,'2023-06-29 01:48:37',NULL),(38,12,1,NULL,3,12.45,'6',0.00,74.70,'2023-06-29 01:48:42',NULL);
/*!40000 ALTER TABLE `order_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `commune_id` bigint(20) unsigned NOT NULL,
  `post_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(8,2) NOT NULL,
  `discount` double(8,2) DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_day` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_month` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmed_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processing_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picked_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipped_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_day` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancel_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancel_order_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `return_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_order_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,1,'738010','note','Cash On Delivery','Cash On Delivery',NULL,'1769752567922396','NFS3460171748',235.80,0.00,'usd','26-06-2023 15:20:54','26','06','2023','26-06-2023 15:36:19','26-06-2023 15:36:45',NULL,NULL,'26-06-2023 15:36:58','26','06','2023',NULL,'0','26-06-2023 15:45:14','Broken Product','2','delivered','2023-06-26 08:20:54','2023-06-26 08:52:14'),(2,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,9,'738010','note','Cash On Delivery','Cash On Delivery',NULL,'1769752844960233','NFS2700685199',58.95,0.00,'usd','26-06-2023 15:23:54','26','06','2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'26-06-2023 15:45:21','2',NULL,NULL,'0','pending','2023-06-26 08:23:54','2023-06-26 09:57:34'),(3,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,7,'738010','note','Stripe Payment','Credit Card','cs_test_a1qOrRxA5S8Xl5fpBUuqsYHiVrT6n7hbpJmwWVL4Ng2zOVzg7RirHDLL0D','1769753110485493','NFS6024437454',20.40,20.40,'usd','26-06-2023 15:28:10','26','06','2023','26-06-2023 16:07:46','26-06-2023 16:07:50',NULL,NULL,'26-06-2023 16:07:53','26','06','2023',NULL,'0',NULL,NULL,'0','delivered','2023-06-26 08:28:10','2023-06-26 09:07:53'),(4,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,6,'738010','note','Mollie Payment','Credit Card','tr_EV8aDom4rn','1769753210690661','NFS3392759950',22.95,0.00,'usd','26-06-2023 15:29:44','26','06','2023','27-06-2023 07:49:27','27-06-2023 07:49:31',NULL,NULL,'27-06-2023 07:49:37','27','06','2023',NULL,'0',NULL,NULL,'0','delivered','2023-06-26 08:29:44','2023-06-27 00:49:37'),(5,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,5,'738010','note','Cash On Delivery','Cash On Delivery',NULL,'1769753353837362','NFS8590903301',77.40,51.60,'usd','26-06-2023 15:31:59','26','06','2023','26-06-2023 16:59:53','26-06-2023 16:59:56',NULL,NULL,'26-06-2023 17:00:54','26','06','2023',NULL,'0',NULL,NULL,'0','delivered','2023-06-26 08:31:59','2023-06-26 10:00:54'),(6,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 17, 14 Street',1,13,4,'730900','note','Cash On Delivery','Cash On Delivery',NULL,'1769754002874120','NFS1309635943',15.65,15.65,'usd','26-06-2023 15:42:18','26','06','2023','27-06-2023 07:52:00','27-06-2023 07:52:04',NULL,NULL,'27-06-2023 07:52:08','27','06','2023',NULL,'0',NULL,NULL,'0','delivered','2023-06-26 08:42:18','2023-06-27 00:52:08'),(7,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 17, 14 Street',1,13,2,'730800','note','Cash On Delivery','Cash On Delivery',NULL,'1769754065118540','NFS4055631517',113.25,0.00,'usd','26-06-2023 15:43:18','26','06','2023','28-06-2023 07:57:03','28-06-2023 07:57:07',NULL,NULL,'28-06-2023 07:57:10','28','06','2023',NULL,'0',NULL,NULL,'0','delivered','2023-06-26 08:43:18','2023-06-28 00:57:10'),(8,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,5,'738010','notes','Cash On Delivery','Cash On Delivery',NULL,'1769866934394690','NFS8290735688',60.60,60.60,'usd','27-06-2023 21:37:18','27','06','2023','29-06-2023 06:46:11','29-06-2023 06:46:14',NULL,NULL,'29-06-2023 06:46:21','29','06','2023',NULL,'0',NULL,NULL,'0','delivered','2023-06-27 14:37:18','2023-06-28 23:46:21'),(9,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,6,'738010','note','Cash On Delivery','Cash On Delivery',NULL,'1769906547136205','NFS4225367119',125.00,0.00,'usd','28-06-2023 08:06:56','28','06','2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'0','pending','2023-06-28 01:06:56',NULL),(10,3,'Minh Kiet','laiminhkiet07052002@gmail.com','0793442309','No 7, T14 Street',1,13,9,'738010','note','Stripe Payment','Credit Card','cs_test_a1gHrk25SnRFu4OcMZwEegjopicp9p4lgGQnOhg6bF3QAaK1F95kPUdVYn','1769948929251022','NFS9537344972',100.00,0.00,'usd','28-06-2023 19:20:35','28','06','2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'0','pending','2023-06-28 12:20:35',NULL),(11,8,'le nguyen hoang phuc','hoangphuc270502@gmail.com','0332964322','13',1,13,9,'700930','notess','Stripe Payment','Credit Card','cs_test_a1DDlNlAs6zBaluhmzkrSXCeTi3aErbRLrpdCbAoKAOItNirSAXiI1M9HV','1769999765697330','NFS8817286754',74.70,0.00,'usd','29-06-2023 08:48:37','29','06','2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'0','pending','2023-06-29 01:48:37',NULL),(12,8,'le nguyen hoang phuc','hoangphuc270502@gmail.com','0332964322','13',1,13,9,'700930','notess','Stripe Payment','Credit Card','cs_test_a1hoOrmdFSz1D9d4EBe1nSEGcecKMsgSSqbBtW8YPfdxMYR05g9lb4rmqY','1769999770824961','NFS7230012265',74.70,0.00,'usd','29-06-2023 08:48:42','29','06','2023','29-06-2023 08:56:21','29-06-2023 08:56:28',NULL,NULL,'29-06-2023 08:56:35','29','06','2023',NULL,'0',NULL,NULL,'0','delivered','2023-06-29 01:48:42','2023-06-29 01:56:35');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'brand.menu','web','brand','2023-06-29 07:03:20','2023-06-29 07:03:20'),(2,'brand.list','web','brand','2023-06-29 07:03:20','2023-06-29 07:03:20'),(3,'brand.add','web','brand','2023-06-29 07:03:20','2023-06-29 07:03:20'),(4,'brand.edit','web','brand','2023-06-29 07:03:20','2023-06-29 07:03:20'),(5,'brand.delete','web','brand','2023-06-29 07:03:20','2023-06-29 07:03:20'),(6,'brand.restore','web','brand','2023-06-29 07:03:20','2023-06-29 07:03:20'),(7,'category.menu','web','category','2023-06-29 07:03:20','2023-06-29 07:03:20'),(8,'category.list','web','category','2023-06-29 07:03:20','2023-06-29 07:03:20'),(9,'category.add','web','category','2023-06-29 07:03:20','2023-06-29 07:03:20'),(10,'category.edit','web','category','2023-06-29 07:03:20','2023-06-29 07:03:20'),(11,'category.delete','web','category','2023-06-29 07:03:20','2023-06-29 07:03:20'),(12,'category.restore','web','category','2023-06-29 07:03:20','2023-06-29 07:03:20'),(13,'subcategory.menu','web','subcategory','2023-06-29 07:03:20','2023-06-29 07:03:20'),(14,'subcategory.list','web','subcategory','2023-06-29 07:03:20','2023-06-29 07:03:20'),(15,'subcategory.add','web','subcategory','2023-06-29 07:03:20','2023-06-29 07:03:20'),(16,'subcategory.edit','web','subcategory','2023-06-29 07:03:20','2023-06-29 07:03:20'),(17,'subcategory.delete','web','subcategory','2023-06-29 07:03:20','2023-06-29 07:03:20'),(18,'subcategory.restore','web','subcategory','2023-06-29 07:03:20','2023-06-29 07:03:20'),(19,'product.menu','web','product','2023-06-29 07:03:20','2023-06-29 07:03:20'),(20,'product.list','web','product','2023-06-29 07:03:20','2023-06-29 07:03:20'),(21,'product.add','web','product','2023-06-29 07:03:20','2023-06-29 07:03:20'),(22,'product.edit','web','product','2023-06-29 07:03:20','2023-06-29 07:03:20'),(23,'product.delete','web','product','2023-06-29 07:03:20','2023-06-29 07:03:20'),(24,'product.restore','web','product','2023-06-29 07:03:20','2023-06-29 07:03:20'),(25,'inventory.menu','web','inventory','2023-06-29 07:03:20','2023-06-29 07:03:20'),(26,'slider.menu','web','slider','2023-06-29 07:03:20','2023-06-29 07:03:20'),(27,'slider.list','web','slider','2023-06-29 07:03:20','2023-06-29 07:03:20'),(28,'slider.add','web','slider','2023-06-29 07:03:20','2023-06-29 07:03:20'),(29,'slider.edit','web','slider','2023-06-29 07:03:20','2023-06-29 07:03:20'),(30,'slider.delete','web','slider','2023-06-29 07:03:20','2023-06-29 07:03:20'),(31,'banner.menu','web','banner','2023-06-29 07:03:20','2023-06-29 07:03:20'),(32,'banner.list','web','banner','2023-06-29 07:03:20','2023-06-29 07:03:20'),(33,'banner.add','web','banner','2023-06-29 07:03:20','2023-06-29 07:03:20'),(34,'banner.edit','web','banner','2023-06-29 07:03:20','2023-06-29 07:03:20'),(35,'banner.delete','web','banner','2023-06-29 07:03:20','2023-06-29 07:03:20'),(36,'coupon.menu','web','coupon','2023-06-29 07:03:20','2023-06-29 07:03:20'),(37,'coupon.list','web','coupon','2023-06-29 07:03:20','2023-06-29 07:03:20'),(38,'coupon.add','web','coupon','2023-06-29 07:03:20','2023-06-29 07:03:20'),(39,'coupon.edit','web','coupon','2023-06-29 07:03:20','2023-06-29 07:03:20'),(40,'coupon.delete','web','coupon','2023-06-29 07:03:20','2023-06-29 07:03:20'),(41,'coupon.restore','web','coupon','2023-06-29 07:03:20','2023-06-29 07:03:20'),(42,'ship.menu','web','ship','2023-06-29 07:03:20','2023-06-29 07:03:20'),(43,'order.menu','web','order','2023-06-29 07:03:20','2023-06-29 07:03:20'),(44,'return.order.menu','web','order','2023-06-29 07:03:20','2023-06-29 07:03:20'),(45,'cancel.order.menu','web','order','2023-06-29 07:03:20','2023-06-29 07:03:20'),(46,'report.menu','web','order','2023-06-29 07:03:20','2023-06-29 07:03:20'),(47,'blog.menu','web','website management','2023-06-29 07:03:20','2023-06-29 07:03:20'),(48,'review.menu','web','website management','2023-06-29 07:03:20','2023-06-29 07:03:20'),(49,'setting.menu','web','website management','2023-06-29 07:03:20','2023-06-29 07:03:20'),(50,'roles.permissions.menu','web','roles and permissions','2023-06-29 07:03:20','2023-06-29 07:03:20'),(51,'admin.user.menu','web','admin user account','2023-06-29 07:03:20','2023-06-29 07:03:20'),(52,'vendor.management.menu','web','vendor and user management','2023-06-29 07:03:20','2023-06-29 07:03:20'),(53,'user.management.menu','web','vendor and user management','2023-06-29 07:03:20','2023-06-29 07:03:20');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT NULL,
  `vendor_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `product_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_weight` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_measure` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_dimensions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturing_date` timestamp NULL DEFAULT NULL,
  `expiry_date` timestamp NULL DEFAULT NULL,
  `selling_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hot_deals` int(11) DEFAULT NULL,
  `featured` int(11) DEFAULT NULL,
  `special_offer` int(11) DEFAULT NULL,
  `special_deals` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_product_code_unique` (`product_code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,NULL,7,9,'11111','Happy Eggs in a box of 10','happy-eggs-in-a-box-of-10','upload/products/thumbnail/1769645840880255_product_thumbnail.jpg','83','new product','60','gram',NULL,'2023-06-24 17:00:00','2024-06-24 17:00:00','20','15.50','Box of 10 Happy Eggs are packed and preserved according to strict standards of hygiene and food safety, ensuring the quality of food.','<p>Product TypeChicken eggs<br>Place of manufacture in Vietnam<br>Storage Store in a cool, dry place<br>Shelf life 14 days at 30 - 35 degrees C. 30 days at 7 - 10 degrees C</p>',NULL,NULL,1,NULL,1,'2023-06-25 04:03:07','2023-06-27 00:52:08',NULL),(2,1,NULL,7,10,'22222','4KFarm salted duck eggs box of 4','4kfarm-salted-duck-eggs-box-of-4','upload/products/thumbnail/1769646354806738_product_thumbnail.jpg','192','new product','100','gram',NULL,'2023-06-24 17:00:00','2025-06-24 17:00:00','15','10.5','The box of 4 salted duck eggs is packed and preserved according to strict standards of hygiene and food safety, ensuring the quality of the food, with a clear origin. Duck eggs are round and even. This is a ready-to-eat grass product, can be eaten with rice or eaten without,.','<p>Product type: Salted duck eggs<br>Egg sauce with 4 eggs<br>Place of manufacture in Vietnam<br>Storage: Store in a cool, dry place<br>Shelf life 30 days from the date of packaging</p>',NULL,NULL,NULL,1,1,'2023-06-25 04:11:17','2023-06-27 00:49:37',NULL),(3,1,NULL,6,12,'33333','Fresh egg tart with Karo golden cheese pack 156g','fresh-egg-tart-with-karo-golden-cheese-pack-156g','upload/products/thumbnail/1769646606061964_product_thumbnail.jpg','278','new product','156','gram',NULL,'2023-06-24 17:00:00','2025-06-24 17:00:00','14','12.45','With a compact design, Karo fresh cake has brought delicious and attractive Karo golden cheese egg tarts (6 packs). In addition, the fresh bread provides abundant energy with fresh ingredients, safe for users\' health.','<p>Product Type Fresh egg tarts<br>Weight :156g<br>Ingredients Fresh chicken eggs (22.3%), chicken flakes (9.4%) (fresh chicken 21%, fish sauce, salt, soy sauce), flour, refined sugar, vegetable oil, malt, sweetener (420ii), humectant (422), emulsifier (322, 475, 1520, 471), foaming agent (500ii), acidity regulator (330), preservative (202, 282). ),...<br>How to use Peel the cake, eat it immediately, avoid leaving it in the air for a long time, it will affect the quality of the cake.<br>Storage Store at room temperature, in a cool, dry place, away from direct sunlight<br>Note Do not use when allergic to any ingredient of the product<br>Brand: Karo<br>Place of manufacture in Vietnam</p>',NULL,1,NULL,NULL,1,'2023-06-25 04:15:17','2023-06-29 01:56:35',NULL),(4,1,NULL,6,11,'44444','Strawberry Chocolate Oreo Pie 360g (12 pcs)','strawberry-chocolate-oreo-pie-360g-(12-pcs)','upload/products/thumbnail/1769646840982646_product_thumbnail.jpg','388','new product','360','gram',NULL,'2023-06-24 17:00:00','2025-06-24 17:00:00','13','5.5','Strawberry Chocolate Oreo Pie in box of 360g (12 pieces) with each layer of delicious chocolate chocolate cake combined with sweet strawberry marshmallow filling. Oreo chocopie cake is a new product combined with the famous group Blackpink, increasing the appeal of the product.','<p>Type of cake Strawberry chocolate cake<br>Quantity: 12 pieces x 30g<br>Total weight: 360g<br>Energy: 437 kcal/100g<br>Ingredients Sugar, Wheat Flour, Malt, Vegetable Oil, Egg, Humectant, Cocoa Powder (4%), Whey Powder, Emulsifier, Gelatin, Salt, Foaming Agent, Flavouring (synthetic strawberry flavour, natural and synthetic chocolate flavor, natural and synthetic vanilla flavor, synthetic caramel flavor), acidity regulator, stabilizer, preservative, synthetic colorant, ....<br>Note Product contains eggs, milk, soy, wheat<br>Storage Store in a cool and dry place, away from direct sunlight<br>Brand Oreo (USA)<br>Place of manufacture in Vietnam</p>',1,NULL,NULL,NULL,1,'2023-06-25 04:19:01','2023-06-27 00:52:08',NULL),(5,1,NULL,5,5,'55555','12 packs of Pedigree Beef Sauce for Big Dogs 80g','12-packs-of-pedigree-beef-sauce-for-big-dogs-80g','upload/products/thumbnail/1769647032046925_product_thumbnail.jpg','485','new product','80','gram',NULL,'2023-06-24 17:00:00','2024-06-24 17:00:00','12',NULL,'Comes in a paste form that you can mix with rice or grain food. Pedigree Sauce for Big Dogs Beef Flavor 80g bag contains a variety of nutrients and vitamins, helps strengthen the immune system and help dogs develop comprehensively.','<p>Brand: Pedigree<br>Made in Thailand<br>Product type Sauce for big dogs with beef flavor<br>The taste of beef cooked with sauce<br>Quantity 12 packs<br>Ingredients Chicken by-products, chicken meat, chicken liver, Wheat gluten, beef liver 1.98%, gelling agent, fiber, minerals, soybean oil, vitamins,...<br>Nutritional composition Moisture max 85%, crude protein min 7%, crude fat min 3%, crude fiber max 1%, , total minerals max 3%<br>Age/kg Over 18 months<br>Instructions for use Based on the number of months, there will be a suitable amount of food on the package<br>Store in a cool, dry place, protected from direct light</p>',NULL,NULL,1,1,1,'2023-06-25 04:22:03','2023-06-28 00:57:10',NULL),(6,1,'2',1,13,'66666','Baby white cabbage 300g','baby-white-cabbage-300g','upload/products/thumbnail/1769667856171672_product_thumbnail.jpg','112','new product','300','gram',NULL,'2023-06-24 17:00:00','2024-06-29 17:00:00','11','10.3','Baby bok choy is a vegetable variety that is grown and packed according to strict standards, ensuring green - clean, quality and safe standards for users. Small crispy sweet bok choy, contains a lot of fiber, so it is often used to boil or stir-fry to keep the freshness of vegetables.','<p>Nutritional value of baby bok choy<br>In bok choy contains a lot of fiber good for the digestive system, especially contains a lot of vitamin A, vitamin B, vitamin C, .. and other minerals good for the body.<br>In 100g of bok choy contains 13.1 Kcal<br>Health benefits of baby bok choy<br>Cancer prevention<br>Contains a lot of fiber to prevent constipation effectively.<br>Effective in preventing cataracts.<br>Reduces high blood pressure and stabilizes heart rate.<br>Fiber creates a feeling of fullness and vitamins and minerals support effective weight loss.<br>Folic acid is abundant in bok choy to help prevent birth defects. On the other hand, eating a lot of bok choy helps mothers increase the amount of breast milk.<br>Vitamin C helps strengthen the immune system and prevent colds.</p>',1,NULL,NULL,NULL,1,'2023-06-25 09:53:03','2023-06-28 23:46:21',NULL),(7,1,'2',2,8,'77777','Thaifruitz Dried Strawberries 30g','thaifruitz-dried-strawberries-30g','upload/products/thumbnail/1769759176154214_product_thumbnail.jpg','97','new product','30','gram',NULL,'2023-06-25 17:00:00','2024-06-29 17:00:00','30',NULL,'Dried fruit is flexible, fragrant, sweet, chewy and very pleasant to eat. Thaifruitz freeze-dried strawberries, pack 30g, are dried by using high temperature (50 - 70 degrees Celsius) to lose some of the product\'s moisture and then cooling. Thaifruitz dried fruit quality, hygienic and attractive.','<p>Product Type Dried Strawberries<br>Drying formDrying plasticizer - using high temperature (50 - 70 degrees Celsius) to lose some of the water vapor of the product and then cooling it.<br>Characteristic: Flexible, soft, slightly chewy<br>Weight 30g<br>Ingredients Fresh Strawberry 95%, Sugar<br>Store in a cool, dry place, away from sunlight<br>Brand Thaifruitz (Vietnam)<br>Place of manufacture in Vietnam</p>',NULL,1,NULL,NULL,1,'2023-06-26 10:04:32','2023-06-28 23:46:21',NULL),(8,1,'2',3,4,'88888','Frozen imported squid beard 500g','frozen-imported-squid-beard-500g','upload/products/thumbnail/1769759500226105_product_thumbnail.jpg','198','new product','500','gram',NULL,NULL,NULL,'25','13.50','The squid whiskers are fresh and delicious, with a chewy, crunchy taste. Squid whiskers are seafood that create many delicious dishes, loved and trusted by housewives, used as ingredients for the whole family\'s meals.','<p>The squid whiskers are fresh, crunchy, quality, carefully packed. Big beard, must be very attractive.</p>\r\n<p>Frozen squid whiskers, guaranteed clear origin, well preserved.</p>\r\n<p>Order fast delivery</p>\r\n<p>Frozen imported squid beard 500g 0<br>Nutritional value of squid beard<br>Squid beard is one of the seafood with high nutritional value, containing a lot of vitamin A, vitamin C, protein, calcium, fat, potassium, magnesium, ... necessary for the body.</p>\r\n<p>In 100g squid beard contains about 92 Kcal</p>\r\n<p>Effects of squid beard on health<br>Helps the body absorb and use iron optimally</p>\r\n<p>Helps support and maintain skin health</p>\r\n<p>Helps strengthen bones, prevent arthritis</p>\r\n<p>They are also very good for the heart</p>\r\n<p>&hellip;</p>',1,NULL,NULL,NULL,1,'2023-06-26 10:09:41','2023-06-28 23:46:21',NULL),(9,1,'2',4,1,'99999','6 bottles of Coca Cola soft drink 390ml','6-bottles-of-coca-cola-soft-drink-390ml','upload/products/thumbnail/1769759624732687_product_thumbnail.jpg','199','new product','390','mililiter',NULL,'2023-06-25 17:00:00','2024-06-25 17:00:00','35',NULL,'From the world\'s leading soft drink brand, Coca Cola soft drink 390ml bottle quickly dispels all feelings of fatigue and stress, especially suitable for outdoor activities. The batch of 6 Coca Cola soft drinks bottles 390ml has a compact bottle design, convenient for easy storage.','<p>About the brand<br>Coca-Cola soft drink (also known as Coca, Coke) is the world\'s leading prestigious brand of the Coca-Cola Company. The company was established in 1893 in the US, with a long journey in the field of soft drinks, Coca-Cola is loved by many people with its delicious and attractive taste.</p>\r\n<p>Nutritional ingredients in the product<br>In 100ml of Coca-Cola soft drink there are:</p>\r\n<p>10.5g carbohydrates</p>\r\n<p>10.5g sugar</p>\r\n<p>23mg Sodium</p>\r\n<p>Provides the body 42 kcal</p>\r\n<p>Health effects<br>6 bottles of Coca Cola 390ml soft drink not only help quench thirst but also provide energy and abundant mineral content, allowing you to rekindle your excitement from the first sip.<br>With a traditional Cola flavor that brings a feeling of refreshment and instant cooling, Coca Cola beverage with a large amount of gas will help you quickly dispel all feelings of fatigue and stress, especially suitable for use with activities. outdoor movement. In addition, the product is designed in a convenient can, easy to store as well as carry in picnics, competitions, sports training ...</p>',NULL,NULL,1,NULL,1,'2023-06-26 10:11:40','2023-06-28 23:46:21',NULL),(10,2,'2',6,12,'10101','Oreo Mini Cookies Chocolate Cream 20.4g','oreo-mini-cookies-chocolate-cream-20.4g','upload/products/thumbnail/1769937510073967_product_thumbnail.jpg','100','new product','20','gram',NULL,'2023-06-27 17:00:00','2025-06-28 17:00:00','40','10','Delicious chocolate cream biscuits, with a black crust, slightly bitter but not too sweet to stimulate the taste buds. Oreo Mini Cookies Chocolate Cream Pack of 20.4g of nutrition, delicious, just eat and play. Oreo cookies can be dipped in milk very interesting or as a baking ingredient','<p>Type Chocolate Cream Cookies<br>Weight 20.4g (About 7 pieces)<br>Energy 110kcal/ 23g<br>Ingredients Wheat flour, sugar, non-hydrogenated vegetable oil (palm oil - antioxidant TBHQ (319)), cocoa powder (4.5%), fructose syrup, foaming agent (sodium hydrogen carbonate (500ii), ammonium hydrogen carbonate (503ii), cornstarch, salt, emulsifier (lecithin (322i) of soy origin), natural vanilla flavor.<br>Storage Store in a cool, dry place, away from direct sunlight<br>Note The product contains wheat flour and soybeans, Produced on a cake production line that contains milk and peanuts (groundnut).<br>Brand Oreo (USA)<br>Place of ManufactureIndonesia</p>',NULL,NULL,NULL,1,1,'2023-06-28 09:19:05',NULL,NULL),(11,2,'2',6,12,'12123','Oreo Cadbury Chocolate Cake 180g box','oreo-cadbury-chocolate-cake-180g-box','upload/products/thumbnail/1769937676449960_product_thumbnail.jpg','100','new product','28','gram',NULL,'2023-06-27 17:00:00','2025-06-27 17:00:00','30.0','25.0','With a layer of delicious chocolate cream, full of flavor without being bored. Oreo Cadbury chocolate pie 180g nutrition box, for those who love chocolate. Oreo chocolate cake can be given as a gift, or eaten by the family. Exceptional premium quality products.','<p>Type of cake Chocolate pie<br>Quantity 6 packs x 30g<br>Total weight180g<br>Energy434kcal<br>Ingredients Sugar, Wheat Flour, Egg, Vegetable Oil, Malt, Humectant, , Mixture, Emulsifier, Gelatin, Salt, Flavouring, Cocoa Butter,...<br>Note Product contains eggs, milk, soy, wheat<br>Storage Store in a cool and dry place, away from direct sunlight<br>Brand Oreo ()<br>Place of manufacture in Vietnam</p>',NULL,NULL,1,NULL,1,'2023-06-28 09:21:43','2023-06-28 14:51:34',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_product_id_foreign` (`product_id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (1,6,3,'Vegetables are an extremely important and necessary food for human health. Among the popular vegetables like spinach, tomatoes, carrots, water spinach, bok choy and many more, I find spinach to be one of the most amazing. Spinach contains many essential vitamins and minerals, which help strengthen immunity and fight diseases.','5',2,'1','2023-06-25 14:48:30','2023-06-25 14:58:10'),(2,1,3,'Oke!','5',NULL,'1','2023-06-26 10:05:39','2023-06-26 10:06:04'),(3,6,8,'bad','2',2,'1','2023-06-29 02:17:22','2023-06-29 02:18:34'),(4,6,3,'badly','3',2,'1','2023-06-29 02:21:36','2023-06-29 02:21:57'),(5,6,3,'broken','1',2,'1','2023-06-29 02:29:19','2023-06-29 02:29:47');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(1,2),(2,1),(2,2),(3,1),(3,2),(4,1),(4,2),(5,1),(5,2),(6,1),(6,2),(7,1),(7,2),(8,1),(8,2),(9,1),(9,2),(10,1),(10,2),(11,1),(11,2),(12,1),(12,2),(13,1),(13,2),(14,1),(14,2),(15,1),(15,2),(16,1),(16,2),(17,1),(17,2),(18,1),(18,2),(19,1),(19,2),(20,1),(20,2),(21,1),(21,2),(22,1),(22,2),(23,1),(23,2),(24,1),(24,2),(25,1),(25,2),(26,1),(26,2),(27,1),(27,2),(28,1),(28,2),(29,1),(29,2),(30,1),(30,2),(31,1),(31,2),(32,1),(32,2),(33,1),(33,2),(34,1),(34,2),(35,1),(35,2),(36,1),(36,2),(37,1),(37,2),(38,1),(38,2),(39,1),(39,2),(40,1),(40,2),(41,1),(41,2),(42,1),(42,2),(43,1),(43,2),(44,1),(44,2),(45,1),(45,2),(46,1),(46,2),(47,1),(47,2),(48,1),(48,2),(49,1),(49,2),(50,1),(51,1),(52,1),(53,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'SuperAdmin','web','2023-06-26 02:29:19','2023-06-26 02:29:19'),(2,'Admin','web','2023-06-26 02:29:23','2023-06-26 02:29:23'),(4,'CEO','web','2023-06-29 02:12:22','2023-06-29 02:12:22');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `seos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keyword` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `seos` WRITE;
/*!40000 ALTER TABLE `seos` DISABLE KEYS */;
INSERT INTO `seos` VALUES (1,'Nest','Nest','Meat, Fish, Egg, Milk','The Best Organic Products Online','2023-06-25 04:39:43',NULL);
/*!40000 ALTER TABLE `seos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ship_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ship_cities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `city_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ship_cities` WRITE;
/*!40000 ALTER TABLE `ship_cities` DISABLE KEYS */;
INSERT INTO `ship_cities` VALUES (1,'Ho Chi Minh city','2023-06-25 04:29:08',NULL,NULL),(2,'Ha Noi city','2023-06-25 04:29:12',NULL,NULL),(3,'Da Nang city','2023-06-25 04:29:16',NULL,NULL);
/*!40000 ALTER TABLE `ship_cities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ship_communes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ship_communes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `city_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `commune_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ship_communes` WRITE;
/*!40000 ALTER TABLE `ship_communes` DISABLE KEYS */;
INSERT INTO `ship_communes` VALUES (1,1,13,'An Phu Tay commune','2023-06-25 04:31:43',NULL,NULL),(2,1,13,'Tan Quy Tay commune','2023-06-25 04:31:52',NULL,NULL),(3,1,13,'Da Phuoc commue','2023-06-25 04:32:00',NULL,NULL),(4,1,13,'Vinh Loc B commune','2023-06-25 04:32:06',NULL,NULL),(5,1,13,'Vinh Loc A commune','2023-06-25 04:32:11',NULL,NULL),(6,1,13,'Le Minh Xuan commune','2023-06-25 04:32:27',NULL,NULL),(7,1,13,'Hung Long commnue','2023-06-25 04:32:39',NULL,NULL),(8,1,13,'Quy Duc commune','2023-06-25 04:32:50',NULL,NULL),(9,1,13,'Binh Chanh commune','2023-06-25 04:33:03',NULL,NULL);
/*!40000 ALTER TABLE `ship_communes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ship_districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ship_districts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `city_id` bigint(20) unsigned NOT NULL,
  `district_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ship_districts` WRITE;
/*!40000 ALTER TABLE `ship_districts` DISABLE KEYS */;
INSERT INTO `ship_districts` VALUES (1,1,'District 1','2023-06-25 04:29:24',NULL,NULL),(2,1,'District 2','2023-06-25 04:29:31',NULL,NULL),(3,1,'District 3','2023-06-25 04:29:37',NULL,NULL),(4,1,'District 4','2023-06-25 04:29:45',NULL,NULL),(5,1,'District 5','2023-06-25 04:30:33',NULL,NULL),(6,1,'District 6','2023-06-25 04:30:40',NULL,NULL),(7,1,'District 7','2023-06-25 04:30:46',NULL,NULL),(8,1,'District 8','2023-06-25 04:30:52',NULL,NULL),(9,1,'District 9','2023-06-25 04:30:58',NULL,NULL),(10,1,'District 10','2023-06-25 04:31:04',NULL,NULL),(11,1,'District 11','2023-06-25 04:31:13',NULL,NULL),(12,1,'District 12','2023-06-25 04:31:18',NULL,NULL),(13,1,'Binh Chanh district','2023-06-25 04:31:27','2023-06-25 04:31:32',NULL);
/*!40000 ALTER TABLE `ship_districts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `support_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_us_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hours` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pinterest` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'upload/logo/1769647990657590_logo.svg','1900 - 999','1900 900','nest@gmail.com','Ho Chi Minh city, Viet Nam.','09:00 - 21:00, Mon - Sun','https://www.facebook.com/laiminhkiet752','https://twitter.com/Kiet070502','https://www.youtube.com/channel/UCx7yneP9y9BDz776MzIkdqg','https://www.instagram.com/kiet_7522/','https://www.pinterest.com/kietminh070502/','Nest. 2023 All rights reserved','2023-06-25 04:34:30','2023-06-25 04:37:17');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sliders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slider_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slider_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('show','hide') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'show',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
INSERT INTO `sliders` VALUES (1,'Fresh Vegetables Big Discount','Save up to 50% off on your first order','upload/slider/1769647113915006_slider.png','show','2023-06-25 04:23:22',NULL),(2,'Don’t miss amazing grocery deals','Sign up for the daily newsletter','upload/slider/1769647122929714_slider.png','show','2023-06-25 04:23:30',NULL);
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `subcategory_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_categories_subcategory_name_unique` (`subcategory_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
INSERT INTO `sub_categories` VALUES (1,4,'C2','c2','2023-06-25 03:50:54','2023-06-25 03:50:54',NULL),(2,4,'GREEN TEA','green-tea','2023-06-25 03:54:25','2023-06-25 03:54:45',NULL),(3,3,'SHARK','shark','2023-06-25 03:54:57','2023-06-25 03:54:57',NULL),(4,3,'SQUID','squid','2023-06-25 03:55:14','2023-06-25 03:55:14',NULL),(5,5,'DOG\'S FOOD','dog\'s-food','2023-06-25 03:55:25','2023-06-25 03:55:44',NULL),(6,5,'CAT\'S FOOD','cat\'s-food','2023-06-25 03:55:53','2023-06-25 03:55:53',NULL),(7,2,'GRAPE','grape','2023-06-25 03:57:19','2023-06-25 03:57:19',NULL),(8,2,'STRAWBERRY','strawberry','2023-06-25 03:57:31','2023-06-25 03:57:31',NULL),(9,7,'DUCK\'S EGG','duck\'s-egg','2023-06-25 03:57:50','2023-06-25 03:57:50',NULL),(10,7,'QUAIL EGGS','quail-eggs','2023-06-25 03:58:13','2023-06-25 03:58:13',NULL),(11,6,'POROUS CAKE','porous-cake','2023-06-25 03:58:33','2023-06-25 03:58:33',NULL),(12,6,'CUSTARD CAKE','custard-cake','2023-06-25 03:58:45','2023-06-25 03:58:45',NULL),(13,1,'BROCCOLI','broccoli','2023-06-25 07:01:24','2023-06-25 07:01:24',NULL),(14,1,'SPINACH','spinach','2023-06-25 07:01:44','2023-06-25 07:01:44',NULL);
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shop_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendor_join` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendor_short_info` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('admin','vendor','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `last_seen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_phone_unique` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'SuperAdmin','','superadmin','superadmin@gmail.com','2023-06-25 04:38:43','$2y$10$pVHqEbnEGq.kaMSKbQSG/u347Eyz4Osnxrz/keVtWpyaLVjuy0KBm','1769826218799972_admin.jpg','0376707091','Sailing Tower, 111A Pasteur Street, District 1, Ho Chi Minh City',NULL,NULL,NULL,NULL,'admin','active','2023-06-29 15:50:10',NULL,'2023-06-25 03:22:55','2023-06-29 08:50:10'),(2,'Nature Food','Nature Food','naturefood','naturefood@gmail.com','2023-06-25 04:38:40','$2y$10$6b5Q7sjJpkgfqxhsiif5xuifViUDi1gWvOLKC5bP.KhlMNPpKmiuu','1769648252211242_vendor.png','0342449594','246, street 8, Ward 6, Vo Gap district, Ho Chi Minh city','2023','Lorem ipsum dolor sit, amet consectetur adipisicing elit. \r\nAnimi, quas veniam? Quisquam aliquid ipsum alias, ipsa quasi veritatis porro quidem, fuga deserunt magnam illum rem quod.',NULL,NULL,'vendor','active','2023-06-29 09:08:00',NULL,'2023-06-25 03:22:55','2023-06-29 02:08:00'),(3,'Minh Kiet','','laiminhkiet','laiminhkiet07052002@gmail.com','2023-06-25 04:38:43','$2y$10$aMHkLYXKjFkmMWQUnUwW9e2FlvspCs7ZL55g/Qn/KjgN9vAo/V8iy','1769648355286070_user.jpg','0793442309',NULL,NULL,NULL,NULL,NULL,'user','active','2023-06-29 09:31:08',NULL,'2023-06-25 03:22:56','2023-06-29 02:31:08'),(4,'Admin',NULL,'admin','admin@gmail.com','2023-06-29 05:42:13','$2y$10$pVHqEbnEGq.kaMSKbQSG/u347Eyz4Osnxrz/keVtWpyaLVjuy0KBm','1769820137253465_admin.png','0332964321','Flat Number 1134, 136 Ho Tung Mau street, Mai Dich ward, Cau Giay District, Ha Noi',NULL,NULL,NULL,NULL,'admin','active','2023-06-29 14:39:20',NULL,'2023-06-27 02:06:54','2023-06-29 07:39:20'),(7,'Fruit Shop','Fruit Shop','fruitshop','fruitshop@gmail.com','2023-06-29 05:42:17','$2y$10$xT.NrsibRSyrnqxRCfbVwuCO2U1q5nMaoT4aoxpPnik14RPkXdwQm',NULL,'0981466522',NULL,'2023',NULL,NULL,NULL,'vendor','active','2023-06-28 09:19:42',NULL,'2023-06-28 01:29:00','2023-06-28 02:19:42'),(8,'Hoang Phuc',NULL,'lenguyenhoangphuc','hoangphuc270502@gmail.com','2023-06-28 01:42:01','$2y$10$u02r6kAKRa.temRFnqFHEOFkIBND720XOm8UdPWVIkodNTMAJaCOu',NULL,NULL,'Number 930, Hoang Anh Gia Lai Apartment Block, Nguyen Thi Thap Street, District 7, Ho Chi Minh City',NULL,NULL,NULL,NULL,'user','active','2023-06-29 09:19:00',NULL,'2023-06-28 01:40:10','2023-06-29 02:19:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `wishlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wishlists` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `wishlists` WRITE;
/*!40000 ALTER TABLE `wishlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `wishlists` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

